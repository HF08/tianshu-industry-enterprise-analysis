window.researchReport=(()=>{
  const $=s=>document.querySelector(s);
  function el(parent,tag,text,cls){const node=document.createElement(tag);if(text!=null)node.textContent=text;if(cls)node.className=cls;parent.append(node);return node;}
  const fmt=n=>typeof n==='number'?n.toLocaleString('zh-CN',{maximumFractionDigits:2}):String(n);
  const display=r=>r.unit==='元'?fmt(r.value/1e8)+' 亿元':fmt(r.value)+' '+(r.unit||'');
  function catalogue(ledger,competition){
    const candidates=[...ledger.metrics,...ledger.interim.map(o=>({name:o.field,value:o.value,year:o.period,unit:o.unit,dimension:o.dimension||'',inputs:[o.id]}))];
    for(const r of competition?.rows||[])if(r.name==='同业候选营收相对倍数'||r.name==='代表企业样本营收占比')candidates.push(r);
    return candidates.filter(r=>r.inputs?.length&&['number','string'].includes(typeof r.value)).map((r,i)=>({...r,id:'D'+(i+1)}));
  }
  function prepare(s,ledger,competition){
    const rows=catalogue(ledger,competition);
    return {target:s.plan.target,type:s.plan.type,scope:s.plan.scope,question:s.research,asOf:s.asOf,snapshot:s.snapshot,ledger,rows,
      chainStudy:s.agentOutput?.SUPPLY?.report?.chainStudy,chainFailure:s.agentOutput?.SUPPLY?.error,graph:s.messages.find(m=>m.result?.chainGraph)?.result.chainGraph,
      failures:s.messages.filter(m=>m.error).map(m=>m.from+'：'+m.error)};
  }
  function valid(result,rows){
    const ids=new Set(rows.map(r=>r.id));
    return ['conclusions','risks'].every(k=>Array.isArray(result?.[k])&&result[k].every(x=>x&&typeof x.text==='string'&&x.text.trim()&&Array.isArray(x.refs)&&x.refs.length&&x.refs.every(id=>ids.has(id))&&[...((x.text||'')+' '+(x.counter||'')).matchAll(/\{\{(D\d+)\}\}/g)].every(m=>x.refs.includes(m[1]))))&&Array.isArray(result.gaps)&&result.gaps.every(x=>typeof x==='string')&&(!ids.size||result.conclusions.length>0);
  }
  function bind(session){
    const dialog=$('#research-report'),source=$('#research-source'),panel=$('#research-pages'),toggle=$('#report-toggle');
    let report,active,stack=[],observations=new Map(),origin=null;
    const dock=$('.composer-dock');
    const citationStatus=el(dialog.querySelector('header'),'small',null,'report-citation-status');
    citationStatus.setAttribute('role','status');
    function toggleLabel(open){const text=open?'收起报告':'展开报告';$('#report-toggle-label').textContent=text;toggle.title=text;toggle.setAttribute('aria-label',text);toggle.setAttribute('aria-expanded',String(open));}
    const tip=el(dialog,'div',null,'report-tip');tip.id='report-hover-preview';tip.setAttribute('role','tooltip');
    const menu=el(dialog,'div',null,'rf-menu');menu.setAttribute('aria-label','数据操作');
    const citeItem=el(menu,'button','引用','rf-menu-item'),sourceItem=el(menu,'button','查看来源','rf-menu-item');
    function hideTip(){tip.classList.remove('open');}
    function dismiss(restore=false){hideTip();menu.classList.remove('open');if(restore&&origin?.isConnected)origin.focus({preventScroll:true});hideTip();}
    function close(){dismiss();stack=[];if(source.open)source.close();if(dialog.open)dialog.close();toggleLabel(false);}
    function place(node,x,y){
      const rect=node.getBoundingClientRect(),w=document.documentElement.clientWidth,h=window.innerHeight;
      node.style.left=Math.max(6,Math.min(w-rect.width-6,x+rect.width+14>w?x-rect.width-8:x+8))+'px';
      node.style.top=Math.max(6,Math.min(h-rect.height-6,y+rect.height+18>h?y-rect.height-8:y+12))+'px';
    }
    function provenance(r){
      const o=r.inputs?.length===1?observations.get(r.inputs[0]):null;
      const formula=o?.formula&&(!r.formula||r.formula===o.field)?o.formula:r.formula;
      if(r.claim)return {label:'分析推断'};
      if(formula&&(!o||formula!==o.field))return {label:'计算',formula,inputs:o?.formula===formula?o.inputs:r.inputs};
      return {label:'提取'};
    }
    function evidence(r){
      const docs=new Set(),seen=new Set();
      function visit(id){if(seen.has(id))return;seen.add(id);const o=observations.get(id);if(o?.source&&report.ledger.sources[o.source])docs.add(report.ledger.sources[o.source]);(o?.inputs||[]).forEach(visit);}
      r.inputs.forEach(visit);return [...docs];
    }
    function citeRow(r,compose=false){
      const s=session(),key=report.snapshot+'/'+r.id,label=r.claim?r.value:r.name+' · '+r.year;
      const urls=evidence(r).map(d=>d.url||d.url_or_document).filter(Boolean);
      const c={key,label,text:[report.target,report.snapshot,label,r.dimension,display(r),r.formula,...urls].filter(Boolean).join(' | ')};
      s.citations||=[];if(!s.citations.some(v=>v.key===key))s.citations.push(c);
      chips();position();dismiss();$('#report-exit').title='关闭报告，输入框中已有 '+s.citations.length+' 项引用';if(compose){if(source.open)source.close();$('#composer-input').focus();}
    }
    function sync(){close();const s=session();toggle.disabled=!s?.reports?.length;toggle.title=toggle.disabled?'完成研究后查看本会话报告':'展开本会话报告';$('#report-toggle-label').textContent='展开报告';chips();}
    function chips(){
      const wrap=$('#composer-attach');wrap.replaceChildren();
      for(const c of session()?.citations||[]){const b=el(wrap,'span',null,'cite-chip');b.title=c.label;el(b,'span',c.label,'cite-text');const remove=el(b,'button','×','cite-x');remove.type='button';remove.setAttribute('aria-label','移除引用：'+c.label);remove.onclick=()=>{const s=session();s.citations=s.citations.filter(v=>v!==c);chips();};}
      wrap.hidden=!wrap.children.length;citationStatus.textContent=wrap.children.length?'已引用 '+wrap.children.length+' 项 · 可在下方继续追问':'';citationStatus.hidden=!wrap.children.length;
    }
    function proof(r){
      dismiss();const b=$('#proof-body');b.replaceChildren();$('#proof-title').textContent=r.claim?'判断依据':r.name+' · '+display(r);
      if(stack.length){const back=el(b,'button','← 返回上一级');back.onclick=()=>proof(stack.pop());}
      if(r.claim){el(b,'h4',r.value);if(r.counter)el(b,'p',r.counter);for(const ref of r.refs)point(b,ref);}
      el(b,'p',[report.target,r.year,r.dimension||'研究标的口径'].join(' · '));
      const basis=provenance(r);el(b,'strong',basis.label,'basis-label');el(b,'p',basis.formula?'计算公式　'+basis.formula:basis.label==='提取'?'提取出处（文档、表或字段）':'关联依据');if(basis.formula&&!r.operands){for(const id of basis.inputs||[]){const o=observations.get(id);if(o&&Number.isFinite(o.value))el(b,'p',o.field+' = '+fmt(o.value)+' '+o.unit+'（'+(o.period||o.year)+'）');}el(b,'p','结果：'+display(r));}if(r.operands)el(b,'p',r.operands);
      const obs=new Map([...report.ledger.observations,...report.ledger.interim].map(o=>[o.id,o]));
      const used=new Set(),links=[];
      function addSource(meta){
        if(!meta)return;
        el(b,'p',[meta.publisher,meta.title||meta.table,meta.published&&'发布 '+meta.published,meta.locator,meta.scope].filter(Boolean).join(' · '),'meta');
        if(meta.excerpt)el(b,'blockquote',meta.excerpt);
        const url=meta.url||meta.url_or_document;
        if(typeof url==='string'&&/^https?:\/\//i.test(url)){
          const a=el(b,'a',/\.pdf(?:$|\?)/i.test(url)?'打开原始 PDF ↗':'打开来源网页或数据接口 ↗');
          const page=String(meta.locator||'').match(/PDF\s*第?\s*(\d+)\s*页/i);
          a.href=page&&/\.pdf(?:$|\?)/i.test(url)?url.split('#')[0]+'#page='+page[1]:url;
          a.target='_blank';a.rel='noopener noreferrer';links.push(a.href);
        }else if(url)el(b,'small','文档标识：'+url);
      }
      function walk(id){
        if(used.has(id))return;used.add(id);
        const o=obs.get(id);
        if(!o){el(b,'p',id.startsWith('calendar-')?'年度天数基数：'+id:'输入记录：'+id);return;}
        el(b,'h4',o.field+' · '+(o.period||o.year));
        if(Array.isArray(o.value)){
          const pre=el(b,'details');el(pre,'summary','查看样本数据（'+o.value.length+' 项）');el(pre,'pre',JSON.stringify(o.value,null,2));
        }else if(r.rawId!==id)point(b,{id:'input:'+id,rawId:id,name:o.field,year:o.period||o.year,dimension:o.dimension||'',value:o.value,unit:o.unit,formula:o.formula,inputs:[id]});
        else el(b,'p',fmt(o.value)+' '+o.unit);
        if(o.formula)el(b,'small',o.formula);
        addSource(report.ledger.sources[o.source]);if(r.rawId===id)(o.inputs||[]).forEach(walk);
      }
      if(!r.claim)r.inputs.forEach(walk);
      const filing=report.type==='company'&&!r.name.startsWith('同业')&&Object.values(report.ledger.sources).find(s=>s.url&&s.title?.includes(String(r.year))&&s.title.includes('年度报告'));
      if(filing&&!links.includes(filing.url)){el(b,'h4','同期年报核对入口');addSource(filing);}
      const cite=el(b,'button','引用并追问','primary');cite.onclick=()=>citeRow(r,true);
      source.displayedRecord=r;if(!source.open)source.showModal();source.scrollTop=0;b.scrollTop=0;
    }
    const rowLabel=r=>[r.year,r.dimension,r.name].filter(Boolean).join(' · ');
    function point(parent,r,label){
      const btn=el(parent,'button',label||rowLabel(r)+'　'+display(r),'metric-link');
      btn.type='button';btn.setAttribute('aria-haspopup','true');
      function preview(e){
        if(menu.classList.contains('open'))return;
        const host=btn.closest('dialog');host.append(tip);tip.replaceChildren();
        const head=el(tip,'div',null,'tip-head');
        el(head,'span',provenance(r).label,'tip-kind '+(r.claim?'infer':provenance(r).formula?'calc':'direct'));
        el(head,'strong',r.name,'tip-title');el(tip,'div',display(r));
        const doc=evidence(r)[0];el(tip,'small',[r.year,r.dimension,doc?.title||doc?.table||doc?.publisher].filter(Boolean).join(' · '));
        if(provenance(r).formula)el(tip,'div','公式 · '+provenance(r).formula);if(r.claim)el(tip,'div','关联依据：'+r.refs.map(v=>v.name).join('、'));
        if(r.operands)el(tip,'div',r.operands);
        if(provenance(r).formula&&!r.operands&&!r.claim){const values=r.inputs.map(id=>observations.get(id)).filter(o=>o&&typeof o.value==='number').slice(0,3);if(values.length)el(tip,'div',values.map(o=>o.field+' '+display(o)).join('；'));}
        if(doc?.locator)el(tip,'div',doc.locator);
        tip.classList.add('open');const rect=btn.getBoundingClientRect();place(tip,e.clientX||rect.left,e.clientY||rect.bottom);
      }
      btn.onpointerenter=preview;btn.onpointermove=e=>{if(tip.classList.contains('open'))place(tip,e.clientX,e.clientY);};btn.onpointerleave=hideTip;
      btn.onfocus=preview;btn.onblur=hideTip;
      btn.oncontextmenu=e=>{e.preventDefault();btn.onclick(e);};
      btn.onkeydown=e=>{if(e.key==='ContextMenu'||e.shiftKey&&e.key==='F10'){e.preventDefault();btn.click();}};
      btn.onclick=e=>{
        e.stopPropagation();dismiss();origin=btn;btn.closest('dialog').append(menu);menu.classList.add('open');
        const rect=btn.getBoundingClientRect();place(menu,e.clientX||rect.left,e.clientY||rect.bottom);
        citeItem.onclick=()=>citeRow(r);
        sourceItem.onclick=()=>{if(source.open)stack.push(source.displayedRecord);else stack=[];proof(r);};
        if(!e.detail)citeItem.focus({preventScroll:true});
      };return btn;
    }
    function section(name){const s=el(panel,'section',null,'report-section');el(s,'h3',name);return s;}
    function charts(title,rows){
      const sectionEl=section(title);
      const groups=new Map();
      for(const r of rows.filter(x=>typeof x.value==='number')){
        const key=r.name+' · '+(r.dimension||'整体')+'（'+r.unit+'）';if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r);
      }
      if(!groups.size){el(sectionEl,'p','缺少同口径可绘制数据。');return;}
      const select=el(sectionEl,'select');select.setAttribute('aria-label',title+'指标');
      for(const key of groups.keys())select.add(new Option(key,key));
      const bars=el(sectionEl,'div',null,'bars');
      function draw(){bars.replaceChildren();const series=groups.get(select.value).slice().sort((a,b)=>String(a.year).localeCompare(String(b.year)));
        const max=Math.max(...series.map(r=>Math.abs(r.value)),0.000001);
        for(const r of series){const btn=point(bars,r,'');btn.replaceChildren();el(btn,'span',r.year);const rail=el(btn,'i');const bar=el(rail,'b');bar.style.width=Math.abs(r.value)/max*100+'%';if(r.value<0)bar.className='negative';el(btn,'strong',display(r));}
      }select.onchange=draw;draw();
    }
    function comparison(){
      const area=section('代表企业与竞争格局'),rows=report.rows.filter(r=>['同业候选营收相对倍数','代表企业样本营收占比'].includes(r.name));
      if(!rows.length){el(area,'p','缺少同期间可比企业样本，竞争位置待核实。');return;}
      el(area,'p',report.type==='company'?'同分类上市公司合并营业总收入 ÷ 标的营业总收入。候选企业的产品、地域重叠程度须单独核实。':'样本内合并营业总收入占比，统计范围为所选分类的上市公司。');
      const bars=el(area,'div',null,'bars'),max=Math.max(...rows.map(r=>r.value),0.0001);
      for(const r of rows){const btn=point(bars,r);btn.replaceChildren();el(btn,'span',r.dimension);el(el(btn,'i'),'b').style.width=r.value/max*100+'%';el(btn,'strong',display(r));}
    }
    function inline(parent,text,refs){
      const allowed=new Map(refs.map(r=>[r.id,r]));
      const tokens=String(text||'').split(/(\{\{D\d+\}\})/g);
      for(const token of tokens){
        if(/^\{\{D\d+\}\}$/.test(token)){const r=allowed.get(token.slice(2,-2));if(r)point(parent,r,display(r));else parent.append('（依据待核）');}
        else parent.append(token.replace(/^[【][^】]{1,20}[】]/,''));
      }
    }
    function notes(title,items){
      const area=section(title);if(!items.length)el(area,'p','当前证据不足以形成有依据的判断。');
      for(const [i,x] of items.entries()){
        const refs=x.refs.map(id=>report.rows.find(r=>r.id===id)).filter(Boolean);
        const p=el(area,'p',null,'research-prose');inline(p,x.text,refs);
        if(!x.text.includes('{{')&&refs.length){p.append(' 依据：');refs.slice(0,2).forEach((r,j)=>{if(j)p.append('、');point(p,r,r.year+' 年'+r.name+' '+display(r));});}
        if(x.counter){const sub=el(area,'p',null,'analysis-limit');inline(sub,x.counter,refs);}
      }
    }
    function annualChange(parent,name){
      const list=report.rows.filter(r=>r.name===name&&Number.isInteger(r.year)&&typeof r.value==='number').sort((a,b)=>b.year-a.year);
      for(const now of list){
        const prev=list.find(r=>r.year===now.year-1&&r.dimension===now.dimension&&r.unit===now.unit);
        if(!prev)continue;
        const diff=now.value-prev.value,unit=now.unit==='%'?'个百分点':now.unit;
        const change={id:'delta-'+now.id,name:name+'年度变动',year:now.year,dimension:now.dimension,value:diff,unit,inputs:[...new Set([...now.inputs,...prev.inputs])],formula:'本期指标 − 上期同口径指标',operands:display(now)+' − '+display(prev)+' = '+display({value:diff,unit})};
        const line=el(parent,'p',null,'research-prose');line.append((now.dimension||report.target)+'的'+name+'由 '+prev.year+' 年的');point(line,prev,display(prev));line.append('变为 '+now.year+' 年的');point(line,now,display(now));line.append('，较上年'+(diff>=0?'增加':'减少'));point(line,change,display({value:Math.abs(diff),unit}));line.append('。');break;
      }
    }
    function draw(){
      dismiss();const s=session();report=s.reports.at(-1);panel.replaceChildren();
      observations=new Map([...report.ledger.observations,...report.ledger.interim].map(o=>[o.id,o]));
      $('#live-report-title').textContent=report.target+'研究报告';$('#report-stamp').textContent='资料截止 '+report.asOf+' · '+(report.fallback?'部分交付':'报告代理汇编');
      evidencePages.nav(panel,report,report.ledger,report.target,report.snapshot,report.asOf);
      el(panel,'h3',report.question);el(panel,'p',report.scope+'　·　悬停虚线文字可预览依据，右击可引用或查看来源，触屏可轻点。','report-notice');
      const rows=report.rows;
      const company=report.type==='company';
      const picks=company?['营业收入','归母净利润','经营现金流','资产负债率']:['市场规模','新增并网装机','销量','装车量','CR5','原料价格','产量'];
      notes('研究结论及依据',report.written.conclusions);
      const change=section('经营变化与计算依据');
      for(const name of company?['营业收入','归母净利润','经营现金流']:['新增并网装机','销量','装车量','CR5'])annualChange(change,name);
      if(change.children.length===1)el(change,'p','缺少连续两期可比数据。');
      const tiles=el(panel,'div',null,'report-kpis');
      for(const name of picks){const r=rows.filter(r=>r.name===name).sort((a,b)=>Number(b.year)-Number(a.year))[0];if(!r)continue;const btn=point(tiles,r);btn.replaceChildren();el(btn,'small',r.name+' · '+r.year);el(btn,'strong',display(r));el(btn,'small',r.dimension||'合并口径');}
      charts(company?'五年经营变化':'行业规模、供需与周期',rows.filter(r=>!company||!r.dimension));
      if(company)charts('产品收入与盈利结构',rows.filter(r=>r.dimension&&/产品收入占比|分部毛利率|分部收入增速/.test(r.name)));
      comparison();
      const chain=section('产业链分析');let plotted=false;
      if(report.chainStudy&&window.supplyNetwork){window.supplyNetwork.mount(chain,report.chainStudy,Object.assign({},report.ledger.sources,Object.fromEntries(report.ledger.observations.filter(o=>o.source&&report.ledger.sources[o.source]).map(o=>[o.id,report.ledger.sources[o.source]]))));plotted=true;}
      if(report.chainFailure)el(chain,'p','产业链代理回报缺失：'+report.chainFailure,'meta');
      try{if(!plotted&&report.graph)plotted=window.chainMap.mount(el(chain,'div'),report.graph);}catch{}
      if(!plotted){
        const edges=report.ledger.observations.filter(o=>o.field==='产业链关系'&&o.value?.from&&o.value?.to);
        if(edges.length)for(const o of edges)point(chain,{id:o.id,name:o.value.type,year:o.year,dimension:o.dimension,value:o.value.from+' → '+o.value.to,unit:'',inputs:[o.id]});
        else{
          const stages=company?[
            ['上游采购',r=>r.name==='前五供应商采购占比'],
            ['企业业务',r=>r.name==='产品收入占比'&&!/^其中/.test(r.dimension)],
            ['下游销售',r=>r.name==='前五客户销售占比（披露）']
          ]:[
            ['上游材料',r=>r.name==='原料价格'],
            ['中游产销',r=>['产量','销量'].includes(r.name)],
            ['下游应用',r=>r.name==='装车量']
          ];
          const flow=el(chain,'div',null,'stage-flow');
          for(const [title,choose] of stages){
            const candidates=rows.filter(choose).sort((a,b)=>Number(b.year)-Number(a.year));
            if(!candidates.length)continue;
            const stage=el(flow,'article');el(stage,'h4',title);
            for(const r of candidates.filter(r=>r.year===candidates[0].year).slice(0,4))point(stage,r);
          }
          el(chain,'p',flow.children.length?'按已披露的采购、生产或销售环节展示；节点指标可点开核验。具名供销关系仍需公告或合同支持。':'尚无可核验的上下游关系。需补充供应、销售、项目定点或行业工艺关系的原文证据。','meta');
        }
      }
      const signals=section('经营变化信号');
      const chosen=company?['经营现金流与净利润比','DIO','资产负债率']:['销量同比','CR5','产能利用率'];
      const signalGrid=el(signals,'div',null,'signal-grid');
      for(const name of chosen){
        const series=rows.filter(r=>r.name===name&&typeof r.value==='number').sort((a,b)=>Number(b.year)-Number(a.year));
        const now=series.find(r=>series.some(p=>p.dimension===r.dimension&&p.unit===r.unit&&Number(p.year)===Number(r.year)-1));
        if(!now)continue;
        const prior=series.find(p=>p.dimension===now.dimension&&p.unit===now.unit&&Number(p.year)===Number(now.year)-1);
        const card=el(signalGrid,'article',null,'signal-card'),diff=now.value-prior.value;
        el(card,'small',name+' · '+(now.dimension||'合并口径'));el(card,'h4',(diff>0?'↑ ':diff<0?'↓ ':'→ ')+fmt(Math.abs(diff))+' '+(now.unit==='%'?'个百分点':now.unit));
        point(card,prior,prior.year+' · '+display(prior));point(card,now,now.year+' · '+display(now));
      }
      if(!signalGrid.children.length)el(signals,'p','缺少连续两个可比期间，无法判断变化方向。');
      notes('经营风险、反证与核查方向',report.written.risks);
      const gaps=section('矛盾与待核实事项');
      const missing=[...new Set([...report.written.gaps,...report.failures,...report.ledger.issues,...report.ledger.conflicts.map(x=>'口径冲突 · '+x.key+' '+x.dimension)])];
      for(const x of missing)el(gaps,'p',x);
      const list=el(gaps,'details');el(list,'summary','查看计算缺项（'+report.ledger.missing.length+'）');
      list.ontoggle=()=>{if(list.open&&list.children.length===1)for(const m of report.ledger.missing)el(list,'p',[m.year,m.dimension,m.name,m.reason||(m.need||[]).join('、')].filter(Boolean).join(' · '));};
      const prev=s.reports.at(-2);
      if(prev&&prev.target===report.target){
        const ch=section('与上一版本比较'),key=r=>JSON.stringify([r.name,r.unit,r.year,r.dimension||'']);
        const old=new Map(prev.rows.map(r=>[key(r),r]));let count=0;
        for(const r of rows){const earlier=old.get(key(r));old.delete(key(r));if(earlier?.value!==r.value){count++;point(ch,r,rowLabel(r)+'　'+(earlier?display(earlier):'新增')+' → '+display(r));}}
        for(const r of old.values()){count++;el(ch,'p',rowLabel(r)+' · 本版缺失');}
        if(!count)el(ch,'p','本次纳入的同口径指标与上一版一致。');
        const priorClaims=new Set(prev.written.conclusions.map(c=>c.text));
        const revised=report.written.conclusions.filter(c=>!priorClaims.has(c.text));
        if(revised.length){el(ch,'h4','本版新增或改写的判断');for(const c of revised)el(ch,'p',c.text);}
      }
      const index=section('来源与披露时间');
      const byUrl=new Map();
      for(const doc of Object.values(report.ledger.sources)){
        const url=doc.url||doc.url_or_document;
        if(typeof url==='string'&&/^https?:\/\//i.test(url)&&!byUrl.has(url))byUrl.set(url,doc);
      }
      const entries=el(index,'details');el(entries,'summary','查看本轮来源（'+byUrl.size+' 个链接）');
      for(const [url,doc] of byUrl){const p=el(entries,'p'),a=el(p,'a',doc.title||doc.table||doc.publisher||'原始资料');a.href=url;a.target='_blank';a.rel='noopener noreferrer';el(p,'small','　'+[doc.publisher,doc.published||doc.updated||'发布日期待核',doc.locator].filter(Boolean).join(' · '));}
    }
    const historyBox=el(dialog,'section',null,'report-replies');historyBox.hidden=true;
    function position(){
      if(!dialog.open)return;
      const rect=dock.getBoundingClientRect(),top=document.querySelector('.topbar').getBoundingClientRect().bottom;
      dialog.style.top=(top+3)+'px';dialog.style.height=Math.max(64,rect.top-top-8)+'px';
    }
    new ResizeObserver(position).observe(dock);window.addEventListener('resize',position);
    function showReplies(){
      historyBox.replaceChildren();const turns=report?.dialogue||[];historyBox.hidden=!turns.length;
      for(const turn of turns){el(historyBox,'strong',turn.q);const answer=el(historyBox,'div',null,'answer-text');answer.innerHTML=turn.html||'';if(!turn.html)answer.textContent='正在回答…';}
      historyBox.scrollTop=historyBox.scrollHeight;
    }
    function startQuestion(q){
      if(!dialog.open||!report)return null;
      const ref=report,turn={q,html:''};(ref.dialogue||=[]).push(turn);showReplies();
      const selected=new Map(ref.rows.map(r=>[r.id,r]));
      const interpret=x=>({...x,values:x.refs.map(id=>selected.get(id)).filter(Boolean).map(r=>({id:r.id,metric:r.name,period:r.year,scope:r.dimension,value:r.value,unit:r.unit,formula:r.formula}))});
      return {data:{target:ref.target,snapshot:ref.snapshot,as_of:ref.asOf,question:ref.question,scope:ref.scope,conclusions:ref.written.conclusions.map(interpret),risks:ref.written.risks.map(interpret),gaps:ref.written.gaps},
        paint(html){turn.html=html;if(report===ref&&dialog.open)showReplies();}};
    }
    function open(){
      const s=session();if(!s?.reports?.length)return;
      if(dialog.open){close();return;}
      draw();dialog.show();showReplies();toggleLabel(true);position();
    }
    toggle.onclick=open;$('#report-exit').onclick=close;$('#proof-close').onclick=()=>source.close();
    for(const d of [source,dialog])d.onclick=e=>{if(e.target===d)d.close();};
    dock.querySelector('.model-btn')?.addEventListener('click',()=>{if(dialog.open)close();},true);
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&dialog.open&&!source.open&&!menu.classList.contains('open')){e.preventDefault();close();}},false);
    document.addEventListener('pointerdown',e=>{if(!menu.contains(e.target))dismiss();},true);
    document.addEventListener('scroll',()=>dismiss(),true);window.addEventListener('resize',()=>dismiss());
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&menu.classList.contains('open')){e.preventDefault();e.stopImmediatePropagation();dismiss(true);}},true);
    for(const d of [source,dialog])d.addEventListener('close',()=>{if(d.open)return;if(d.contains(menu))dismiss();if(d===dialog){toggleLabel(false);}else stack=[];});
    return {sync,close,chips,startQuestion,ready(){toggle.disabled=false;toggle.title='展开报告';if(dialog.open)openLatest();}};
    function openLatest(){close();open();}
  }
  return {prepare,valid,bind,catalogue};
})();
