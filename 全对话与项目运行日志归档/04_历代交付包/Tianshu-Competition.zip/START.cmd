@echo off
for /d %%D in ("%~dp0*") do if exist "%%~fD\server.mjs" if exist "%%~fD\START.cmd" (
  call "%%~fD\START.cmd"
  exit /b
)
echo Please extract the entire archive before starting.
pause
exit /b 1
