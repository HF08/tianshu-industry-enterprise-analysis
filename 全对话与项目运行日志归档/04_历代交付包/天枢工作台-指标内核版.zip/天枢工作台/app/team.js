(() => {
  'use strict';
  const $ = s => document.querySelector(s);
  const names = {FIN:'财务计算', BIZ:'产品与商业模式', COMP:'上下游关联企业及竞争',
    IND:'行业状况（数据）', CHAIN:'上下游分析', DEM:'规模客户', RC:'企业风险模式', RI:'行业风险模式'};
  const teams = {company:['FIN','BIZ','COMP','RC'], industry:['IND','CHAIN','DEM','RI']};
  const sessions = new WeakMap();
  const workspace = $('.workspace'), input = $('#composer-input');
  let current;
  function select(item) {
    if(current){current.draft=input.value;current.feed.remove();}
    if(!sessions.has(item)){
      const feed=document.createElement('div');
      feed.className='conversation';
      sessions.set(item,{item,feed,draft:'',history:[],agents:[],messages:[],queue:Promise.resolve(),phase:'idle'});
    }
    current=sessions.get(item);
    workspace.append(current.feed);
    input.value=current.draft;
    current.feed.hidden=!current.feed.childElementCount;
    $('#workspace-title').hidden=!current.feed.hidden || item.dataset.fresh!=='1';
    window.renderAgentPanel(current.agents);
    workspace.scrollTop=workspace.scrollHeight;
  }
  window.addEventListener('session-selected',e=>select(e.detail));
  select($('.chat-item.active'));
  $('#report-toggle-label').textContent='示例报告';
  function bubble(s,author,text,kind=''){
    const row=document.createElement('article'), label=document.createElement('strong'), body=document.createElement('p');
    row.className=kind;label.textContent=author;body.textContent=text;
    row.append(label,body);
    if(kind==='progress'){
      let log=s.feed.lastElementChild;
      if(!log?.classList.contains('work-log')){
        log=document.createElement('details');log.className='work-log';log.open=true;
        const caption=document.createElement('summary');caption.textContent='工作记录';log.append(caption);s.feed.append(log);
      }
      log.append(row);
    }else{
      s.feed.append(row);
      if(kind==='user'){
        const meta=document.createElement('div'),copy=document.createElement('button');
        meta.className='message-meta';
        meta.append(new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'}));
        copy.type='button';copy.textContent='⧉';copy.title='复制消息';copy.setAttribute('aria-label','复制消息');
        copy.onclick=async()=>{try{await navigator.clipboard.writeText(text);copy.textContent='✓';}catch{copy.title='未取得剪贴板权限';}};
        meta.append(copy);row.append(meta);
      }
    }
    s.feed.hidden=false;
    if(current===s){$('#workspace-title').hidden=true;workspace.scrollTop=workspace.scrollHeight;}
    return body;
  }
  function progress(s,text){bubble(s,'天枢 · 工作进度',text,'progress');}
  function state(s,role,status,task){
    Object.assign(s.agents.find(a=>a.id===role),{status,task});
    if(current===s)window.renderAgentPanel(s.agents);
  }
  function parseJSON(text){return JSON.parse(text.trim().replace(/^\x60\x60\x60(?:json)?\s*/i,'').replace(/\s*\x60\x60\x60$/,''));}
  async function call(s,role,action,context,signal,onText){
    const response=await fetch('/api/stream',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({config:s.config,role,action,context}),signal});
    if(!response.ok)throw Error((await response.text()).slice(0,250));
    const reader=response.body.pipeThrough(new TextDecoderStream()).getReader();
    let pending='',content='',finished=false;
    function line(raw){
      if(!raw.startsWith('data:'))return;
      const data=raw.slice(5).trim();
      if(data==='[DONE]'){finished=true;return;}
      const event=JSON.parse(data);
      if(event.error)throw Error('模型流返回错误');
      const choice=event.choices?.[0];
      if(choice?.finish_reason==='length')throw Error('输出达到模型长度限制，请缩小范围');
      if(choice?.finish_reason==='stop')finished=true;
      const token=choice?.delta?.content;
      if(typeof token==='string'){content+=token;onText?.(token);}
    }
    try{
      while(true){
        const {done,value}=await reader.read();if(done)break;
        pending+=value;
        const lines=pending.split('\n');pending=lines.pop();lines.forEach(line);
      }
      line(pending);
    }finally{await reader.cancel().catch(()=>{});}
    if(!finished||!content.trim())throw Error('模型流中断或返回空内容');
    return content;
  }
  function context(s,history=s.history){
    return {conversation:history.slice(),scope:s.plan,team_messages:s.messages.slice(),agents:s.agents.map(a=>({...a})),phase:s.phase};
  }
  async function reply(s,action,data,signal){
    const body=bubble(s,'天枢','');
    try{
      const text=await call(s,'TS',action,data,signal,token=>{
        const follow=current===s && workspace.scrollHeight-workspace.scrollTop-workspace.clientHeight<80;
        body.append(document.createTextNode(token));
        if(follow)workspace.scrollTop=workspace.scrollHeight;
      });
      formatAnswer(body,text);
      s.history.push({role:'assistant',content:text});
    }catch(e){
      body.append(document.createTextNode(signal?.aborted?'（本轮已由新要求替代）':'（回答未完成）'));throw e;
    }
  }
  function formatAnswer(body,text){
    const blocks=document.createDocumentFragment();
    let list=null;
    for(const line of text.split('\n')){
      const bullet=line.match(/^\s*(?:[-*]|(\d+)\.)\s+(.+)/);
      if(!line.trim()){list=null;continue;}
      let el;
      if(bullet){
        const tag=bullet[1]?'ol':'ul';
        if(list?.localName!==tag){list=document.createElement(tag);if(bullet[1])list.start=Number(bullet[1]);blocks.append(list);}
        el=document.createElement('li');list.append(el);
      }else{list=null;el=document.createElement(/^#{1,6}\s/.test(line)?'h4':'div');blocks.append(el);}
      const value=bullet?bullet[2]:line.replace(/^#{1,6}\s+/,'');
      for(const part of value.split(/(\*\*[^*]+\*\*|\x60[^\x60]+\x60)/g)){
        if(part.startsWith('**')&&part.endsWith('**')){const b=document.createElement('strong');b.textContent=part.slice(2,-2);el.append(b);}
        else if(part.startsWith('\x60')&&part.endsWith('\x60')){const c=document.createElement('code');c.textContent=part.slice(1,-1);el.append(c);}
        else el.append(part);
      }
    }
    const formatted=document.createElement('div');formatted.className='answer-text';formatted.append(blocks);body.replaceWith(formatted);
  }
  async function work(s,id,signal){
    state(s,id,'运行中','正在分析并整理回报');
    progress(s,'已向「'+names[id]+'」派发任务。');
    const upstream=s.messages.slice();
    const task_id=s.snapshot+'-'+id;
    try{
      const data={task_id,snapshot_id:s.snapshot,as_of:s.asOf,target:s.plan.target,question:s.research,
        role:id,scope:s.plan.scope,metric_definitions:'按共享口径，明确单位、分母与可比范围',windows:'财务五个完整财年；近期单列',
        benchmarks:s.plan.scope,required_outputs:'按角色契约交付',upstream_ids:upstream.map(m=>m.id),handoff_to:['TS'],
        upstream,materials:s.materials};
      if(id==='FIN'||id==='IND'){
        const response=await fetch('/api/kernel',{method:'POST',headers:{'Content-Type':'application/json'},signal,
          body:JSON.stringify({role:id,target:data.target,sector:s.plan.sector,as_of:s.asOf,records:s.records||[]})});
        if(!response.ok)throw Error('取数失败：'+await response.text());
        const ledger=await response.json();
        signal.throwIfAborted();
        const summary=bubble(s,'天枢 · 取数完成',names[id]+'：'+ledger.metrics.length+' 条年度结果，'+ledger.interim.length+' 条近期观测。','progress');
        const download=document.createElement('button');
        download.className='btn btn-ghost';download.textContent='下载数据与计算台账';
        download.onclick=()=>{
          const url=URL.createObjectURL(new Blob([JSON.stringify(ledger,null,2)],{type:'application/json'}));
          const link=document.createElement('a');link.href=url;link.download=id+'-'+s.plan.target+'-台账.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),2000);
        };summary.after(download);
        const series=new Map();
        for(const row of ledger.metrics){
          const key=JSON.stringify([row.dimension,row.name,row.unit]);
          if(!series.has(key))series.set(key,{dimension:row.dimension,name:row.name,unit:row.unit,formula:row.formula,values:{}});
          series.get(key).values[row.year]=row.value;
        }
        data.kernel={years:ledger.years,sources:ledger.sources,series:[...series.values()],issues:ledger.issues,conflicts:ledger.conflicts,
          missing_fields:[...new Set(ledger.missing.flatMap(r=>r.need||[r.name]))],interim:ledger.interim};
      }
      const result=parseJSON(await call(s,id,'work',data,signal));
      if(!['complete','partial','blocked'].includes(result.status)||!Array.isArray(result.artifacts)||
          !Array.isArray(result.risk_findings)||typeof result.summary!=='string'||!result.summary.trim())throw Error('回报格式不完整');
      const msg={id:task_id,from:id,to:'TS',result};
      if(data.kernel)msg.kernel=data.kernel;
      s.messages.push(msg);
      state(s,id,'已完成',result.summary);
      const note=bubble(s,'天枢 · 收到团队回报',names[id]+'：'+result.summary+'（'+({complete:'已完成',partial:'部分完成',blocked:'资料受限'}[result.status])+'）','progress');
      const details=document.createElement('details'), summary=document.createElement('summary'), raw=document.createElement('p');
      summary.textContent='查看团队消息';raw.textContent=JSON.stringify(msg,null,2);
      details.append(summary,raw);note.after(details);
    }catch(e){
      if(signal.aborted)throw e;
      s.messages.push({id:task_id,from:id,to:'TS',error:e.message});
      state(s,id,'失败',e.message);progress(s,names[id]+'任务失败：'+e.message);
    }
  }
  async function run(s){
    s.controller?.abort();
    const controller=new AbortController(), signal=controller.signal;
    s.controller=controller;s.phase='planning';s.plan=null;s.messages=[];s.agents=[];
    if(current===s)window.renderAgentPanel([]);
    s.snapshot=crypto.randomUUID();s.asOf=new Date().toISOString();
    s.materials=s.history.filter(m=>m.role==='user').slice();s.research=s.materials.map(m=>m.content).join('\n');
    try{
      progress(s,'正在识别研究标的、时间范围和统计口径。');
      const plan=parseJSON(await call(s,'TS','plan',context(s),signal));
      if(plan.type==='clarify'){
        const question=plan.question||'请补充企业全称或行业范围。';
        bubble(s,'天枢',question);s.history.push({role:'assistant',content:question});s.phase='clarify';return;
      }
      if(!Object.hasOwn(teams,plan.type)||!plan.target||!plan.scope)throw Error('天枢未返回有效的标的和口径，请重试');
      s.plan=plan;s.phase='working';
      const ids=teams[plan.type];
      s.agents=ids.map(id=>({id,name:names[id],status:'等待中',task:'等待派发'}));
      progress(s,'已选择'+(plan.type==='company'?'企业':'行业')+'组 · '+plan.target+'。'+plan.scope);
      await Promise.all(ids.slice(0,3).map(id=>work(s,id,signal)));
      await work(s,ids[3],signal);
      s.phase='synthesizing';progress(s,'本组任务已结束，正在汇总回报与缺口。');
      await reply(s,'final',context(s),signal);s.phase='done';
    }catch(e){if(!signal.aborted){s.phase='failed';bubble(s,'运行提示',e.message,'error');}}
  }
  async function handle(s,history){
    if(['idle','failed','clarify'].includes(s.phase)){void run(s);return;}
    const data=context(s,history);
    const choice=parseJSON(await call(s,'TS','steer',data));
    if(choice.action==='revise'){progress(s,'已收到范围调整，将按更新后的要求重新派单。');void run(s);return;}
    if(choice.action!=='answer')throw Error('未识别插话类型，请重新发送');
    await reply(s,'answer',{...context(s,history),latest_user_message:history.at(-1).content});
  }
  function send(){
    const s=current,text=input.value.trim();if(!text)return;
    if(location.protocol==='file:'){bubble(s,'启动提示','请使用项目内的“启动工作台.cmd”打开本地服务。','error');return;}
    let config;
    try{config=JSON.parse(localStorage.getItem('app.api.config'));}catch{}
    if(!config?.apiKey||!config.baseUrl||!config.model){bubble(s,'配置提示','请先在右上角设置中保存模型地址、API Key 和模型名，再发送。','error');return;}
    s.config=config;
    const chips=[...document.querySelectorAll('.cite-chip')];
    const content=text+(chips.length?'\n引用界面样例（仅作演示）：'+chips.map(c=>c.title).join('、'):'');
    chips.forEach(c=>c.querySelector('button').click());
    if(!s.history.length){
      s.item.dataset.fresh='0';
      s.item.dataset.name=text.slice(0,22);
      s.item.querySelector('.chat-name').textContent=s.item.dataset.name;
      $('#topbar-title').textContent=s.item.dataset.name;
    }
    input.value='';s.history.push({role:'user',content});
    bubble(s,'你',content,'user');
    const history=s.history.slice();
    s.queue=s.queue.then(()=>handle(s,history)).catch(e=>bubble(s,'消息处理失败',e.message,'error'));
  }
  $('.send').addEventListener('click',send);
  $('.circle-plus').title='导入带出处的指标数据（JSON）';
  $('.circle-plus').onclick=()=>{
    const s=current,picker=document.createElement('input');picker.type='file';picker.accept='.json';
    picker.onchange=async()=>{
      try{
        const file=picker.files[0];if(!file)return;
        if(file.size>1500000)throw Error('单个资料包请控制在 1.5 MB 内');
        const rows=JSON.parse((await file.text()).replace(/^\uFEFF/,''));
        if(!Array.isArray(rows)||!rows.every(r=>r&&r.target&&r.field&&r.source&&r.locator&&r.published&&r.unit&&Number.isInteger(r.year)&&['FIN','IND'].includes(r.role)))throw Error('请使用指标接口说明中的记录数组格式');
        s.records=rows;
        progress(s,'已载入 '+file.name+'，共 '+rows.length+' 条记录，下次派单时匹配本次标的。');
      }catch(e){bubble(s,'导入失败',e.message,'error');}
    };picker.click();
  };
  $('#composer').addEventListener('submit',e=>{e.preventDefault();send();});
  input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.keyCode!==229){e.preventDefault();send();}});
})();
