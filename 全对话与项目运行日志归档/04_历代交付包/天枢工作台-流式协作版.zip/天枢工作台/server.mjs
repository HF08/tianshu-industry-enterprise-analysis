import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';

const book = await readFile(new URL('./prompts.md', import.meta.url), 'utf8');
const sections = book.split(/^## /m);
const section = prefix => sections.find(s => s.startsWith(prefix)).split(/^### 企业模式注入词/m)[0];
const roles = {
  TS:'主模型系统', FIN:'研究系统提示词 · 财务', BIZ:'研究系统提示词 · 产品',
  COMP:'研究系统提示词 · 上下游关联', IND:'研究系统提示词 · 行业状况',
  CHAIN:'研究系统提示词 · 上下游分析', DEM:'研究系统提示词 · 规模客户',
  RC:'风险审查系统', RI:'风险审查系统'
};
const modes = Object.fromEntries(['RC','RI'].map((id,i) => [id,
  sections.find(s=>s.startsWith('风险审查系统')).split(/^### /m)[i+1]]));
const actions = {
  plan:'仅进行路由。结合全部用户消息识别标的，返回单一 JSON 对象 {type:"company"或"industry"或"clarify",target:"明确主体",scope:"问题、期间、口径与比较边界",question:"需澄清时的问题"}。意图明确时直接选分支。',
  steer:'判断最新插话对任务的影响：改变研究范围、补充要求或资料返回 {"action":"revise"}；询问进度、解释、相关追问返回 {"action":"answer"}。只返回 JSON。',
  work:'根据输入任务卡执行本角色，只返回共享契约规定的 JSON，额外提供 summary 字符串作为给天枢的简短回报。缺证据时提交结构化缺口。不得编造数据或工具执行。',
  final:'根据已收到的团队消息，用中文直接回答用户的研究问题。简要分段，说明依据、缺口与失败任务。避免复述任务卡或 JSON。',
  answer:'直接回应最后一条用户插话或追问，结合当前状态与已有团队结果；区分进行中与已验证结果。'
};
const staticFiles = {'/':'index.html','/index.html':'index.html','/team.js':'team.js','/team.css':'team.css'};
const mime = {html:'text/html',js:'text/javascript',css:'text/css'};
const server = http.createServer(async (req,res) => {
  const abort = new AbortController();
  res.on('close',()=>abort.abort());
  try {
    const host = '127.0.0.1:'+server.address().port;
    if(req.headers.host !== host) {res.writeHead(403).end();return;}
    if(req.method==='GET' && Object.hasOwn(staticFiles,req.url)){
      const file=staticFiles[req.url];
      const bytes=await readFile(new URL('./app/'+file,import.meta.url));
      res.writeHead(200,{'Content-Type':mime[file.split('.').pop()]+'; charset=utf-8'}).end(bytes);return;
    }
    if(req.method!=='POST'||req.url!=='/api/stream'||req.headers.origin!=='http://'+host){
      res.writeHead(403).end();return;
    }
    let body='';
    req.setEncoding('utf8');
    for await(const part of req){body+=part;if(body.length>3000000)throw Error('会话内容超过单次请求限制');}
    const {config,role,action,context}=JSON.parse(body);
    if(!Object.hasOwn(roles,role)||!Object.hasOwn(actions,action))throw Error('未知任务');
    const url=new URL(config.baseUrl.replace(/\/+$/,'')+'/chat/completions');
    if(url.protocol!=='https:' && !(url.protocol==='http:' && ['localhost','127.0.0.1','[::1]'].includes(url.hostname)))throw Error('远程模型接口需要 HTTPS');
    const system=[section('共享契约'),section(roles[role]),modes[role]||'',
      '当前仅有模型对话能力。研究资料仅限用户实际提供的内容和本轮上游记录；未接入外部检索与财务计算工具。以下为本阶段输出要求：',actions[action]].join('\n');
    const upstream=await fetch(url,{method:'POST',redirect:'error',signal:AbortSignal.any([abort.signal,AbortSignal.timeout(240000)]),
      headers:{'Content-Type':'application/json',Authorization:'Bearer '+config.apiKey},
      body:JSON.stringify({model:config.model,stream:true,messages:[{role:'system',content:system},{role:'user',content:JSON.stringify(context)}]})});
    if(!upstream.ok)throw Error('模型接口返回 HTTP '+upstream.status+'，请检查设置或稍后重试');
    if(!upstream.headers.get('content-type')?.includes('text/event-stream'))throw Error('接口未返回 Chat Completions 流');
    res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-store'});
    for await(const part of upstream.body) res.write(part);
    res.end();
  } catch(e){if(res.headersSent){res.destroy();}else if(!res.destroyed){res.writeHead(400,{'Content-Type':'text/plain;charset=utf-8'}).end(e.message);}}
});
server.listen(Number(process.env.TIANSHU_PORT||18721),'127.0.0.1',()=>{
  const url='http://127.0.0.1:'+server.address().port;
  console.log('天枢工作台 '+url);
  if(process.argv.includes('--open'))spawn('rundll32.exe',['url.dll,FileProtocolHandler',url],{windowsHide:true}).unref();
});
