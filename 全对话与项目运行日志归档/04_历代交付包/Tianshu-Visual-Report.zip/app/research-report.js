window.researchReport=(()=>{
  const $=s=>document.querySelector(s);
  function el(parent,tag,text,cls){const node=document.createElement(tag);if(text!=null)node.textContent=text;if(cls)node.className=cls;parent.append(node);return node;}
  const fmt=n=>typeof n==='number'?n.toLocaleString('zh-CN',{maximumFractionDigits:2}):String(n);
  const display=r=>r.unit==='元'?fmt(r.value/1e8)+' 亿元':fmt(r.value)+' '+(r.unit||'');
  function catalogue(ledger,competition){
    const candidates=[...ledger.metrics,...ledger.interim.map(o=>({name:o.field,value:o.value,year:o.period,unit:o.unit,dimension:o.dimension||'',inputs:[o.id]}))];
    for(const r of competition?.rows||[])if(r.name==='同业候选营收相对倍数'||r.name==='代表企业样本营收占比')candidates.push(r);
    return candidates.filter(r=>r.inputs?.length&&['number','string'].includes(typeof r.value)).map((r,i)=>({...r,id:'D'+(i+1)}));
  }
  function prepare(s,ledger,competition){
    const rows=catalogue(ledger,competition);
    return {target:s.plan.target,type:s.plan.type,scope:s.plan.scope,question:s.research,asOf:s.asOf,snapshot:s.snapshot,ledger,rows,
      graph:s.messages.find(m=>m.result?.chainGraph)?.result.chainGraph,
      failures:s.messages.filter(m=>m.error).map(m=>m.from+'：'+m.error)};
  }
  function valid(result,rows){
    const ids=new Set(rows.map(r=>r.id));
    return ['conclusions','risks'].every(k=>Array.isArray(result?.[k])&&result[k].every(x=>x&&typeof x.text==='string'&&x.text.trim()&&Array.isArray(x.refs)&&x.refs.length&&x.refs.every(id=>ids.has(id))))&&Array.isArray(result.gaps)&&result.gaps.every(x=>typeof x==='string')&&(!ids.size||result.conclusions.length>0);
  }
  function bind(session,onUpdate){
    const dialog=$('#research-report'),source=$('#research-source'),panel=$('#research-pages'),versions=$('#report-version'),toggle=$('#report-toggle');
    let report,active;
    function close(){if(source.open)source.close();if(dialog.open)dialog.close();}
    function sync(){close();const s=session();toggle.disabled=!s?.reports?.length;toggle.title=toggle.disabled?'完成研究后查看本会话报告':'展开本会话报告';$('#report-toggle-label').textContent='展开报告';chips();}
    function chips(){
      const wrap=$('#composer-attach');wrap.replaceChildren();
      for(const c of session()?.citations||[]){const b=el(wrap,'button',c.label+' ×','cite-chip');b.title=c.label;b.onclick=()=>{const s=session();s.citations=s.citations.filter(v=>v!==c);chips();};}
      wrap.hidden=!wrap.children.length;
    }
    function proof(r){
      const b=$('#proof-body');b.replaceChildren();$('#proof-title').textContent=r.name+' · '+display(r);
      el(b,'p',[report.target,r.year,r.dimension||'研究标的口径'].join(' · '));
      el(b,'p',r.formula?'计算公式　'+r.formula:'来源披露或结构化观测');
      const obs=new Map([...report.ledger.observations,...report.ledger.interim].map(o=>[o.id,o]));
      const used=new Set(),links=[];
      function addSource(meta){
        if(!meta)return;
        el(b,'p',[meta.publisher,meta.title||meta.table,meta.published&&'发布 '+meta.published,meta.locator,meta.scope].filter(Boolean).join(' · '),'meta');
        if(meta.excerpt)el(b,'blockquote',meta.excerpt);
        const url=meta.url||meta.url_or_document;
        if(typeof url==='string'&&/^https?:\/\//i.test(url)){
          const a=el(b,'a',/\.pdf(?:$|\?)/i.test(url)?'打开原始 PDF ↗':'打开来源网页或数据接口 ↗');
          const page=String(meta.locator||'').match(/PDF\s*第?\s*(\d+)\s*页/i);
          a.href=page&&/\.pdf(?:$|\?)/i.test(url)?url.split('#')[0]+'#page='+page[1]:url;
          a.target='_blank';a.rel='noopener noreferrer';links.push(a.href);
        }else if(url)el(b,'small','文档标识：'+url);
      }
      function walk(id){
        if(used.has(id))return;used.add(id);
        const o=obs.get(id);
        if(!o){el(b,'p',id.startsWith('calendar-')?'年度天数基数：'+id:'输入记录：'+id);return;}
        el(b,'h4',o.field+' · '+(o.period||o.year));
        if(Array.isArray(o.value)){
          const pre=el(b,'details');el(pre,'summary','查看样本数据（'+o.value.length+' 项）');el(pre,'pre',JSON.stringify(o.value,null,2));
        }else el(b,'p',fmt(o.value)+' '+o.unit);
        if(o.formula)el(b,'small',o.formula);
        addSource(report.ledger.sources[o.source]);(o.inputs||[]).forEach(walk);
      }
      r.inputs.forEach(walk);
      const filing=report.type==='company'&&!r.name.startsWith('同业')&&Object.values(report.ledger.sources).find(s=>s.url&&s.title?.includes(String(r.year))&&s.title.includes('年度报告'));
      if(filing&&!links.includes(filing.url)){el(b,'h4','同期年报核对入口');addSource(filing);}
      const cite=el(b,'button','引用并追问','primary');cite.onclick=()=>{
        const s=session(),key=report.snapshot+'/'+r.id,label=r.name+' · '+r.year;
        const citation={key,label,text:[report.target,report.snapshot,label,r.dimension,display(r),r.formula,...links].filter(Boolean).join(' | ')};
        s.citations||=[];if(!s.citations.some(x=>x.key===key))s.citations.push(citation);
        chips();close();$('#composer-input').focus();
      };
      if(!source.open)source.showModal();
    }
    const rowLabel=r=>[r.year,r.dimension,r.name].filter(Boolean).join(' · ');
    function point(parent,r,label){const btn=el(parent,'button',label||rowLabel(r)+'　'+display(r),'metric-link');btn.title='查看输入值、公式、来源或引用';btn.onclick=()=>proof(r);return btn;}
    function section(name){const s=el(panel,'section',null,'report-section');el(s,'h3',name);return s;}
    function charts(title,rows){
      const sectionEl=section(title);
      const groups=new Map();
      for(const r of rows.filter(x=>typeof x.value==='number')){
        const key=r.name+' · '+(r.dimension||'整体')+'（'+r.unit+'）';if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r);
      }
      if(!groups.size){el(sectionEl,'p','缺少同口径可绘制数据。');return;}
      const select=el(sectionEl,'select');select.setAttribute('aria-label',title+'指标');
      for(const key of groups.keys())select.add(new Option(key,key));
      const bars=el(sectionEl,'div',null,'bars');
      function draw(){bars.replaceChildren();const series=groups.get(select.value).slice().sort((a,b)=>String(a.year).localeCompare(String(b.year)));
        const max=Math.max(...series.map(r=>Math.abs(r.value)),0.000001);
        for(const r of series){const btn=point(bars,r,'');btn.replaceChildren();el(btn,'span',r.year);const rail=el(btn,'i');const bar=el(rail,'b');bar.style.width=Math.abs(r.value)/max*100+'%';if(r.value<0)bar.className='negative';el(btn,'strong',display(r));}
      }select.onchange=draw;draw();
    }
    function comparison(){
      const area=section('代表企业与竞争格局'),rows=report.rows.filter(r=>['同业候选营收相对倍数','代表企业样本营收占比'].includes(r.name));
      if(!rows.length){el(area,'p','缺少同期间可比企业样本，竞争位置待核实。');return;}
      el(area,'p',report.type==='company'?'同分类上市公司合并营业总收入 ÷ 标的营业总收入。候选企业的产品、地域重叠程度须单独核实。':'样本内合并营业总收入占比，统计范围为所选分类的上市公司。');
      const bars=el(area,'div',null,'bars'),max=Math.max(...rows.map(r=>r.value),0.0001);
      for(const r of rows){const btn=point(bars,r);btn.replaceChildren();el(btn,'span',r.dimension);el(el(btn,'i'),'b').style.width=r.value/max*100+'%';el(btn,'strong',display(r));}
    }
    function notes(title,items){
      const area=section(title);if(!items.length)el(area,'p','当前证据不足以形成有依据的判断。');
      for(const x of items){const card=el(area,'article',null,'finding-card');el(card,'strong',x.text);if(x.counter)el(card,'p','反证或限制 · '+x.counter);
        for(const ref of x.refs){const r=report.rows.find(r=>r.id===ref);if(r)point(card,r);}
      }
    }
    function draw(){
      const s=session();report=s.reports[Number(versions.value)];panel.replaceChildren();
      $('#live-report-title').textContent=report.target+'研究报告';$('#report-stamp').textContent='资料截止 '+report.asOf+' · '+(report.fallback?'部分交付':'报告代理汇编');
      el(panel,'h3',report.question);el(panel,'p',report.scope,'meta');
      const rows=report.rows;
      const company=report.type==='company';
      const picks=company?['营业收入','归母净利润','经营现金流','资产负债率']:['市场规模','销量','装车量','CR5','原料价格','产量'];
      const tiles=el(panel,'div',null,'report-kpis');
      for(const name of picks){const r=rows.filter(r=>r.name===name).sort((a,b)=>Number(b.year)-Number(a.year))[0];if(!r)continue;const btn=point(tiles,r);btn.replaceChildren();el(btn,'small',r.name+' · '+r.year);el(btn,'strong',display(r));el(btn,'small',r.dimension||'合并口径');}
      notes('研究结论及依据',report.written.conclusions);
      charts(company?'五年经营变化':'行业规模、供需与周期',rows.filter(r=>!company||!r.dimension));
      if(company)charts('产品收入与盈利结构',rows.filter(r=>r.dimension&&/产品收入占比|分部毛利率|分部收入增速/.test(r.name)));
      comparison();
      const chain=section('产业链与关联关系');let plotted=false;
      try{if(report.graph)plotted=window.chainMap.mount(el(chain,'div'),report.graph);}catch{}
      if(!plotted){
        const edges=report.ledger.observations.filter(o=>o.field==='产业链关系'&&o.value?.from&&o.value?.to);
        if(edges.length)for(const o of edges)point(chain,{id:o.id,name:o.value.type,year:o.year,dimension:o.dimension,value:o.value.from+' → '+o.value.to,unit:'',inputs:[o.id]});
        else{
          const stages=company?[
            ['上游采购',r=>r.name==='前五供应商采购占比'],
            ['企业业务',r=>r.name==='产品收入占比'&&!/^其中/.test(r.dimension)],
            ['下游销售',r=>r.name==='前五客户销售占比（披露）']
          ]:[
            ['上游材料',r=>r.name==='原料价格'],
            ['中游产销',r=>['产量','销量'].includes(r.name)],
            ['下游应用',r=>r.name==='装车量']
          ];
          const flow=el(chain,'div',null,'stage-flow');
          for(const [title,choose] of stages){
            const candidates=rows.filter(choose).sort((a,b)=>Number(b.year)-Number(a.year));
            if(!candidates.length)continue;
            const stage=el(flow,'article');el(stage,'h4',title);
            for(const r of candidates.filter(r=>r.year===candidates[0].year).slice(0,4))point(stage,r);
          }
          el(chain,'p',flow.children.length?'按已披露的采购、生产或销售环节展示；节点指标可点开核验。具名供销关系仍需公告或合同支持。':'尚无可核验的上下游关系。需补充供应、销售、项目定点或行业工艺关系的原文证据。','meta');
        }
      }
      const signals=section('经营变化信号');
      const chosen=company?['经营现金流与净利润比','DIO','资产负债率']:['销量同比','CR5','产能利用率'];
      const signalGrid=el(signals,'div',null,'signal-grid');
      for(const name of chosen){
        const series=rows.filter(r=>r.name===name&&typeof r.value==='number').sort((a,b)=>Number(b.year)-Number(a.year));
        const now=series.find(r=>series.some(p=>p.dimension===r.dimension&&p.unit===r.unit&&Number(p.year)===Number(r.year)-1));
        if(!now)continue;
        const prior=series.find(p=>p.dimension===now.dimension&&p.unit===now.unit&&Number(p.year)===Number(now.year)-1);
        const card=el(signalGrid,'article',null,'signal-card'),diff=now.value-prior.value;
        el(card,'small',name+' · '+(now.dimension||'合并口径'));el(card,'h4',(diff>0?'↑ ':diff<0?'↓ ':'→ ')+fmt(Math.abs(diff))+' '+(now.unit==='%'?'个百分点':now.unit));
        point(card,prior,prior.year+' · '+display(prior));point(card,now,now.year+' · '+display(now));
      }
      if(!signalGrid.children.length)el(signals,'p','缺少连续两个可比期间，无法判断变化方向。');
      notes('经营风险、反证与核查方向',report.written.risks);
      const gaps=section('矛盾与待核实事项');
      const missing=[...new Set([...report.written.gaps,...report.failures,...report.ledger.issues,...report.ledger.conflicts.map(x=>'口径冲突 · '+x.key+' '+x.dimension)])];
      for(const x of missing)el(gaps,'p',x);
      const list=el(gaps,'details');el(list,'summary','查看计算缺项（'+report.ledger.missing.length+'）');
      list.ontoggle=()=>{if(list.open&&list.children.length===1)for(const m of report.ledger.missing)el(list,'p',[m.year,m.dimension,m.name,m.reason||(m.need||[]).join('、')].filter(Boolean).join(' · '));};
      const prev=s.reports[Number(versions.value)-1];
      if(prev&&prev.target===report.target){
        const ch=section('与上一版本比较'),key=r=>JSON.stringify([r.name,r.unit,r.year,r.dimension||'']);
        const old=new Map(prev.rows.map(r=>[key(r),r]));let count=0;
        for(const r of rows){const earlier=old.get(key(r));old.delete(key(r));if(earlier?.value!==r.value){count++;point(ch,r,rowLabel(r)+'　'+(earlier?display(earlier):'新增')+' → '+display(r));}}
        for(const r of old.values()){count++;el(ch,'p',rowLabel(r)+' · 本版缺失');}
        if(!count)el(ch,'p','本次纳入的同口径指标与上一版一致。');
        const priorClaims=new Set(prev.written.conclusions.map(c=>c.text));
        const revised=report.written.conclusions.filter(c=>!priorClaims.has(c.text));
        if(revised.length){el(ch,'h4','本版新增或改写的判断');for(const c of revised)el(ch,'p',c.text);}
      }
      const index=section('来源与披露时间');
      const byUrl=new Map();
      for(const doc of Object.values(report.ledger.sources)){
        const url=doc.url||doc.url_or_document;
        if(typeof url==='string'&&/^https?:\/\//i.test(url)&&!byUrl.has(url))byUrl.set(url,doc);
      }
      const entries=el(index,'details');el(entries,'summary','查看本轮来源（'+byUrl.size+' 个链接）');
      for(const [url,doc] of byUrl){const p=el(entries,'p'),a=el(p,'a',doc.title||doc.table||doc.publisher||'原始资料');a.href=url;a.target='_blank';a.rel='noopener noreferrer';el(p,'small','　'+[doc.publisher,doc.published||doc.updated||'发布日期待核',doc.locator].filter(Boolean).join(' · '));}
    }
    function open(){
      const s=session();if(!s?.reports?.length)return;
      active=s;$('#report-update').disabled=!['done','failed'].includes(s.phase);versions.replaceChildren();s.reports.forEach((r,i)=>versions.add(new Option('版本 '+(i+1)+' · '+r.target,String(i))));
      versions.value=String(s.reports.length-1);draw();dialog.showModal();
    }
    toggle.onclick=open;versions.onchange=draw;$('#report-exit').onclick=close;$('#proof-close').onclick=()=>source.close();
    $('#report-update').onclick=()=>{if(session()!==active)return;const s=session();if(!['done','failed'].includes(s.phase))return;close();onUpdate(s,report);};
    for(const d of [source,dialog])d.onclick=e=>{if(e.target===d)d.close();};
    return {sync,close,chips,ready(){toggle.disabled=false;toggle.title='展开报告';if(dialog.open)openLatest();}};
    function openLatest(){close();open();}
  }
  return {prepare,valid,bind};
})();
