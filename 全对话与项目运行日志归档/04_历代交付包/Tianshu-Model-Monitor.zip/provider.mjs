export function modelRequest(config,url){
  const official=url.hostname==='api.deepseek.com';
  let model=String(config.model||'').trim();
  if(!model)throw Error('请先获取可用模型或输入服务商提供的 API 模型 ID');
  if(official&&/^deepseek[\s_-]*v?4[._-]1[\s_-]*flash(?:[\s_-]*1017)?$/i.test(model))model='deepseek-flash';
  const deepseek=official||/deepseek/i.test(model);
  const effort=config.reasoningEffort||'default';
  const levels=deepseek?['default','low','medium','high','max']:['default','low','medium','high'];
  if(!levels.includes(effort))throw Error('该模型未配置此思考档位；请核对服务商模型 ID');
  return {model,official,effort,options:effort==='default'?{}:{reasoning_effort:effort,...(deepseek?{thinking:{type:'enabled'}}:{})}};
}
const withoutUsage=new Set();
export async function streamUpstream(base,headers,config,messages,signal){
  const request=modelRequest(config,new URL(base));
  const usageKey=base+'|'+request.model;
  const body={model:request.model,stream:true,...request.options,messages};
  if(!withoutUsage.has(usageKey))body.stream_options={include_usage:true};
  const timeout=AbortSignal.timeout(request.effort==='max'?900000:240000);
  const combined=AbortSignal.any([signal,timeout]);
  for(let attempt=0;attempt<3;attempt++){
    const r=await fetch(base+'/chat/completions',{method:'POST',headers,redirect:'error',signal:combined,body:JSON.stringify(body)});
    if(r.ok)return {response:r,request};
    const raw=await r.text();let detail='';
    try{const e=JSON.parse(raw).error;detail=[e?.param,e?.code,e?.message||e].filter(x=>typeof x==='string').join(' · ');}catch{}
    detail=detail.replaceAll(config.apiKey,'[已隐藏]').slice(0,260);
    const invalid=[400,422].includes(r.status);
    if(invalid&&body.stream_options&&/stream_options|include_usage/i.test(detail)){
      delete body.stream_options;withoutUsage.add(usageKey);continue;
    }
    if(invalid&&!request.official&&body.thinking&&/\bthinking\b/i.test(detail)&&/unknown|unrecognized|not supported|unsupported|extra|不支持/i.test(detail)){
      delete body.thinking;continue; // Keep the requested reasoning_effort.
    }
    const hint=invalid&&request.effort==='max'?'；请核对网关是否对该模型开放 max，或使用官方接口。':'';
    throw Error('模型接口 HTTP '+r.status+'（'+request.model+' / '+request.effort+'）'+(detail?'：'+detail:'')+hint);
  }
  throw Error('网关未接受请求参数，请核对模型与接口。');
}
