(() => {
  'use strict';
  const $ = s => document.querySelector(s);
  const names = {FIN:'财务计算', BIZ:'产品与商业模式', COMP:'上下游关联企业及竞争',
    IND:'行业状况（数据）', CHAIN:'上下游分析', DEM:'规模客户', RC:'企业风险模式', RI:'行业风险模式'};
  const teams = {company:['FIN','BIZ','COMP','RC'], industry:['IND','CHAIN','DEM','RI']};
  const sessions = new WeakMap();
  const workspace = $('.workspace'), input = $('#composer-input');
  let current;
  function showPanel(s){
    $('#agent-empty').textContent=({planning:'天枢正在识别标的并组建团队',clarify:'等待补充研究标的',failed:'组队未完成，请查看运行提示'})[s.phase]||'暂无活跃';
    window.renderAgentPanel(s.agents);
  }
  function select(item) {
    if(current){current.draft=input.value;current.feed.remove();}
    if(!sessions.has(item)){
      const feed=document.createElement('div');
      feed.className='conversation';
      sessions.set(item,{item,feed,draft:'',history:[],agents:[],messages:[],queue:Promise.resolve(),phase:'idle'});
    }
    current=sessions.get(item);
    workspace.append(current.feed);
    input.value=current.draft;
    current.feed.hidden=!current.feed.childElementCount;
    $('#workspace-title').hidden=!current.feed.hidden || item.dataset.fresh!=='1';
    showPanel(current);
    workspace.scrollTop=workspace.scrollHeight;
  }
  window.addEventListener('session-selected',e=>select(e.detail));
  select($('.chat-item.active'));
  $('#report-toggle-label').textContent='示例报告';
  function bubble(s,author,text,kind=''){
    const row=document.createElement('article'), label=document.createElement('strong'), body=document.createElement('p');
    row.className=kind;label.textContent=author;body.textContent=text;
    row.append(label,body);
    if(kind==='progress'){
      let log=s.feed.lastElementChild;
      if(!log?.classList.contains('work-log')){
        log=document.createElement('details');log.className='work-log';log.open=true;
        const caption=document.createElement('summary');caption.textContent='工作记录';log.append(caption);s.feed.append(log);
      }
      log.append(row);
    }else{
      s.feed.append(row);
      if(kind==='user'){
        const meta=document.createElement('div'),copy=document.createElement('button');
        meta.className='message-meta';
        meta.append(new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'}));
        copy.type='button';copy.textContent='⧉';copy.title='复制消息';copy.setAttribute('aria-label','复制消息');
        copy.onclick=async()=>{try{await navigator.clipboard.writeText(text);copy.textContent='✓';}catch{copy.title='未取得剪贴板权限';}};
        meta.append(copy);row.append(meta);
      }
    }
    s.feed.hidden=false;
    if(current===s){$('#workspace-title').hidden=true;workspace.scrollTop=workspace.scrollHeight;}
    return body;
  }
  function progress(s,text){bubble(s,'天枢 · 工作进度',text,'progress');}
  function state(s,role,status,task){
    Object.assign(s.agents.find(a=>a.id===role),{status,task});
    if(current===s)showPanel(s);
  }
  function parseJSON(text){
    try{return JSON.parse(text.trim().replace(/^\x60\x60\x60(?:json)?\s*/i,'').replace(/\s*\x60\x60\x60$/,''));}
    catch{throw Error('模型回报格式不完整，请重试');}
  }
  function publicSummary(s,role,anchor){
    let button,caption,full='',done=false;
    function paint(){
      const lines=full.trim().split(/\r?\n/).filter(l=>l.trim());
      const open=button.getAttribute('aria-expanded')==='true';
      caption.textContent=open?full.trim():(done?lines[0]:lines.at(-1))||'';
    }
    return {
      add(delta){
        if(!button){
          button=document.createElement('button');button.type='button';button.className='thought-summary';
          button.setAttribute('aria-expanded','false');button.title=(names[role]||'天枢')+' · 公开工作摘要';
          const label=document.createElement('span');label.textContent='思考 · ';caption=document.createElement('span');
          button.append(label,caption);button.onclick=()=>{button.setAttribute('aria-expanded',String(button.getAttribute('aria-expanded')!=='true'));paint();};
          if(anchor)anchor.before(button);else s.feed.append(button);
        }
        const follow=current===s&&workspace.scrollHeight-workspace.clientHeight-workspace.scrollTop<90;
        full+=delta;paint();if(follow)workspace.scrollTop=workspace.scrollHeight;
      },
      finish(){done=true;if(button)paint();}
    };
  }
  // Keep incomplete protocol markers between SSE events. JSON is consumed by agents only.
  function publicStream(summary,structured,onText){
    const start='【摘要】',end=structured?'【数据】':'【正文】';
    let stage='start',pending='',body='';
    const emit=t=>{if(t){body+=t;onText?.(t);}};
    return {
      push(chunk){
        pending+=chunk;
        if(stage==='start'){
          pending=pending.trimStart();
          if(!pending||start.startsWith(pending)&&pending.length<start.length)return;
          if(pending.startsWith(start)){stage='summary';pending=pending.slice(start.length);}
          else stage='body'; // Providers may return a plain answer or bare JSON.
        }
        if(stage==='summary'){
          const pos=pending.indexOf(end);
          if(pos<0){
            let keep=0;
            for(let n=1;n<end.length;n++)if(pending.endsWith(end.slice(0,n)))keep=n;
            const chunk=pending.slice(0,pending.length-keep);
            if(chunk)summary.add(chunk);
            pending=pending.slice(pending.length-keep);return;
          }
          if(pos)summary.add(pending.slice(0,pos));
          summary.finish();pending=pending.slice(pos+end.length);stage='body';
        }
        emit(pending);pending='';
      },
      finish(){summary.finish();if(stage==='summary')throw Error('模型未返回完整答复，请重试');return body;},
      close(){summary.finish();}
    };
  }
  async function call(s,role,action,context,signal,onText,anchor){
    const response=await fetch('/api/stream',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({config:s.config,role,action,context}),signal});
    if(!response.ok)throw Error((await response.text()).slice(0,250));
    const reader=response.body.pipeThrough(new TextDecoderStream()).getReader();
    let pending='',content='',finished=false;
    const split=['plan','work','answer','final'].includes(action)?publicStream(publicSummary(s,role,anchor),['plan','work'].includes(action),onText):null;
    function line(raw){
      if(!raw.startsWith('data:'))return;
      const data=raw.slice(5).trim();
      if(data==='[DONE]'){finished=true;return;}
      const event=JSON.parse(data);
      if(event.error)throw Error('模型流返回错误');
      const choice=event.choices?.[0];
      if(choice?.finish_reason==='length')throw Error('输出达到模型长度限制，请缩小范围');
      if(choice?.finish_reason==='stop')finished=true;
      const token=choice?.delta?.content;
      if(typeof token==='string'){if(split)split.push(token);else{content+=token;onText?.(token);}}
    }
    try{
      while(true){
        const {done,value}=await reader.read();if(done)break;
        pending+=value;
        const lines=pending.split('\n');pending=lines.pop();lines.forEach(line);
      }
      line(pending);
      if(split)content=split.finish();
    }finally{split?.close();await reader.cancel().catch(()=>{});}
    if(!finished||!content.trim())throw Error('模型流中断或返回空内容');
    return content;
  }
  function context(s,history=s.history){
    return {conversation:history.slice(),scope:s.plan,team_messages:s.messages.slice(),agents:s.agents.map(a=>({...a})),phase:s.phase};
  }
  const markdown=window.markdownit({html:false,breaks:true,linkify:false}).disable('image');
  function displayMarkdown(text){
    const wrapped=text.match(/^\s*`{3}(?:markdown|md)[ \t]*\r?\n([\s\S]*)$/i);
    const source=wrapped?wrapped[1].replace(/\n`{3}\s*$/,''):text;
    if(!source.includes('\t'))return markdown.render(source);
    // Some providers emit TSV for tables. Preserve indentation and fenced code.
    const lines=source.split('\n'),output=[];
    let fence=null;
    for(let i=0;i<lines.length;i++){
      const line=lines[i],marker=line.match(/^ {0,3}(`{3,}|~{3,})/);
      if(marker){
        if(!fence)fence=marker[1];
        else if(marker[1][0]===fence[0]&&marker[1].length>=fence.length)fence=null;
        output.push(line);continue;
      }
      if(fence||/^\s/.test(line)||!line.includes('\t')){output.push(line);continue;}
      const rows=[line.split(/\t+/)];
      while(i+1<lines.length&&!/^\s/.test(lines[i+1])&&lines[i+1].split(/\t+/).length===rows[0].length)rows.push(lines[++i].split(/\t+/));
      if(rows.length===1){output.push(line);continue;}
      const tableRow=cells=>'| '+cells.map(c=>c.trim().replace(/\|/g,'\\|')).join(' | ')+' |';
      output.push('',tableRow(rows[0]),tableRow(rows[0].map(()=>'---')),...rows.slice(1).map(tableRow),'');
    }
    return markdown.render(output.join('\n'));
  }
  async function reply(s,action,data,signal){
    const placeholder=bubble(s,'天枢','');
    const body=document.createElement('div');
    body.className='answer-text';placeholder.replaceWith(body);
    let buffer='',timer;
    function render(){
      if(timer)cancelAnimationFrame(timer);timer=null;
      const follow=current===s && workspace.scrollHeight-workspace.scrollTop-workspace.clientHeight<80;
      body.innerHTML=displayMarkdown(buffer);
      if(follow)workspace.scrollTop=workspace.scrollHeight;
    }
    try{
      const text=await call(s,'TS',action,data,signal,token=>{
        buffer+=token;
        if(!timer)timer=requestAnimationFrame(render);
      },body.parentElement);
      render();s.history.push({role:'assistant',content:text});
    }catch(e){
      render();body.append(document.createTextNode(signal?.aborted?'（本轮已由新要求替代）':'（回答未完成）'));throw e;
    }
  }
  async function fetchLedger(s,id,signal){
    const records=[...(s.records||[])];
    const report=s.report;
    if(report&&report.role===id&&report.target===s.plan.target&&report.published<=s.asOf.slice(0,10)){
      state(s,id,'运行中','提取研报原文并核对数字定位');
      try{
        const extracted=parseJSON(await call(s,id,'extract',{report},signal));
        if(!Array.isArray(extracted.rows))throw Error('未返回候选记录数组');
        const accepted=extracted.rows.filter(r=>r?.kind==='历史实绩'&&r.own_data===true&&r.period_kind==='全年'&&typeof r.excerpt==='string'&&report.text.includes(r.excerpt)&&
          typeof r.locator==='string'&&r.locator.length>0&&report.text.includes(r.locator)&&Number.isFinite(r.value)&&Number.isInteger(r.year)&&
          typeof r.field==='string'&&r.field.trim()&&typeof r.dimension==='string'&&r.dimension.trim()&&typeof r.unit==='string'&&r.unit.trim()&&
          r.excerpt.includes(String(r.year))&&r.excerpt.includes(r.unit)&&
          (r.excerpt.replaceAll(',','').match(/-?\d+(?:\.\d+)?/g)||[]).some(token=>Number(token)===r.value));
        records.push(...accepted.map(r=>({...r,target:report.target,role:id,published:report.published,publisher:report.publisher,source:report.source,method:'上传材料原文匹配，发布者身份与统计方法待外部核验'})));
        progress(s,'研报候选 '+extracted.rows.length+' 条，通过原文、单位和期间校验 '+accepted.length+' 条。');
      }catch(e){signal.throwIfAborted();progress(s,'研报补取未完成：'+e.message+'。继续调用公开数据接口。');}
    }else if(report&&report.role===id)progress(s,'研报标的或发布日期与任务不匹配，本轮未采用。');
    const response=await fetch('/api/kernel',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/x-ndjson'},signal,
      body:JSON.stringify({role:id,target:s.plan.target,sector:s.plan.sector,as_of:s.asOf,records})});
    if(!response.ok)throw Error('取数失败：'+await response.text());
    const reader=response.body.pipeThrough(new TextDecoderStream()).getReader();
    let buffer='',ledger;
    try{
      while(true){
        const {value,done}=await reader.read();
        if(done)break;
        signal.throwIfAborted();
        buffer+=value;
        const lines=buffer.split('\n');buffer=lines.pop();
        for(const line of lines){
          const event=JSON.parse(line);
          if(event.type==='progress')state(s,id,'运行中',event.task);
          if(event.type==='error')throw Error(event.message);
          if(event.type==='result')ledger=event.ledger;
        }
      }
    }finally{await reader.cancel().catch(()=>{});}
    if(!ledger)throw Error('取数连接中断，未取得完整台账');
    return ledger;
  }
  function showTeamReport(note,result){
    const details=document.createElement('details'),title=document.createElement('summary');
    title.textContent='查看团队消息';details.append(title);
    function add(label,items){
      if(!Array.isArray(items))return;
      const lines=[...new Set(items.filter(v=>typeof v==='string'&&v.trim()))].slice(0,6);
      if(!lines.length)return;
      const heading=document.createElement('strong'),body=document.createElement('div');
      heading.textContent=label;body.className='answer-text';
      body.innerHTML=displayMarkdown(lines.map(v=>'- '+v).join('\n'));
      details.append(heading,body);
    }
    const findings=[...result.artifacts,...result.risk_findings];
    add('主要发现',findings.flatMap(f=>(f?.claims||[]).map(c=>c.text)));
    add('判断依据',(result.evidence||[]).map(e=>[e?.title,e?.period_or_date,e?.page_or_table_or_section].filter(v=>typeof v==='string'&&v.trim()).join(' · ')));
    add('待核实事项',[...(result.missing||[]),...findings.flatMap(f=>f?.missing||[])].map(m=>typeof m==='string'?m:m?.impact||m?.field||m?.reason));
    if(details.childElementCount>1)note.after(details);
  }
  async function work(s,id,signal){
    state(s,id,'运行中','准备研究任务与数据口径');
    progress(s,'已向「'+names[id]+'」派发任务。');
    const upstream=s.messages.slice();
    const task_id=s.snapshot+'-'+id;
    try{
      const data={task_id,snapshot_id:s.snapshot,as_of:s.asOf,target:s.plan.target,question:s.research,
        role:id,scope:s.plan.scope,metric_definitions:'按共享口径，明确单位、分母与可比范围',windows:'财务五个完整财年；近期单列',
        benchmarks:s.plan.scope,required_outputs:'按角色契约交付',upstream_ids:upstream.map(m=>m.id),handoff_to:['TS'],
        upstream,materials:s.materials};
      if(id==='FIN'||id==='IND'){
        s.ledger=fetchLedger(s,id,signal);
        const ledger=await s.ledger;
        signal.throwIfAborted();
        const summary=bubble(s,'天枢 · 取数完成',names[id]+'：'+ledger.metrics.length+' 条年度结果，'+ledger.interim.length+' 条近期观测。','progress');
        const download=document.createElement('button');
        download.className='btn btn-ghost';download.textContent='下载数据与计算台账';
        download.onclick=()=>{
          const url=URL.createObjectURL(new Blob([JSON.stringify(ledger,null,2)],{type:'application/json'}));
          const link=document.createElement('a');link.href=url;link.download=id+'-'+ledger.target+'-台账.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),2000);
        };summary.after(download);
        const series=new Map();
        const obsById=new Map(ledger.observations.map(o=>[o.id,o]));
        function origins(id){const o=obsById.get(id);return o?.source?[o.source]:(o?.inputs||[]).flatMap(origins);}
        for(const row of ledger.metrics){
          const key=JSON.stringify([row.dimension,row.name,row.unit]);
          if(!series.has(key))series.set(key,{dimension:row.dimension,name:row.name,unit:row.unit,formula:row.formula,values:{},sources_by_year:{}});
          series.get(key).values[row.year]=row.value;
          series.get(key).sources_by_year[row.year]=[...new Set(row.inputs.flatMap(origins))];
        }
        data.kernel={years:ledger.years,sources:ledger.sources,series:[...series.values()],issues:ledger.issues,conflicts:ledger.conflicts,
          missing_fields:[...new Set(ledger.missing.flatMap(r=>r.need||[r.name]))],interim:ledger.interim};
      }
      if(window.roleTools.titles[id]){
        state(s,id,'运行中','读取本轮共享取数台账');
        const ledger=await s.ledger;
        signal.throwIfAborted();
        state(s,id,'运行中',window.roleTools.titles[id]);
        data.role_kernel=window.roleTools.run(id,ledger,upstream);
        if(['CHAIN','COMP'].includes(id)){
          data.INDUSTRY_DATA={target:ledger.target,years:ledger.years,inputs:ledger.metrics.filter(m=>m.year>=ledger.years.at(-2)&&/原料价格|装车量|产品价格|产量|销量|毛利率|成本|占比/.test(m.name)),
            interim:ledger.interim.filter(o=>o.dimension),sources:ledger.sources,relations:data.role_kernel.rows};
        }
      }
      const operation=data.role_kernel?.operation||'指标计算';
      state(s,id,'运行中',operation+'完成，正在请求模型分析');
      let lastProgress=0,chars=0,note=null,prefix='',briefDone=false;
      // Decode only the leading public summary string, never render partial agent JSON.
      function liveBrief(chunk){
        if(briefDone)return;
        prefix+=chunk;
        const match=prefix.match(/^\s*(?:\x60{3}json\s*)?\{\s*"summary"\s*:\s*"/i);
        if(!match){if(prefix.length>60)briefDone=true;return;}
        const tail=prefix.slice(match[0].length);
        const token=tail.match(/^(?:[^"\\]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*/)[0];
        const message=JSON.parse('"'+token+'"');
        if(message){
          if(!note){note=bubble(s,'天枢 · 团队回报','','progress');note.className='answer-text';}
          note.innerHTML=displayMarkdown(names[id]+'：'+message);
        }
        if(tail[token.length]==='"'||prefix.length>8192){briefDone=true;prefix='';}
      }
      const result=parseJSON(await call(s,id,'work',data,signal,token=>{
        liveBrief(token);
        chars+=token.length;
        if(Date.now()-lastProgress>650&&!signal.aborted){
          state(s,id,'运行中','正在接收模型回报 · '+chars+' 字符');lastProgress=Date.now();
        }
      }));
      signal.throwIfAborted();
      if(!['complete','partial','blocked'].includes(result.status)||!Array.isArray(result.artifacts)||
          !Array.isArray(result.risk_findings)||typeof result.summary!=='string'||!result.summary.trim())throw Error('回报格式不完整');
      const msg={id:task_id,from:id,to:'TS',result};
      if(data.kernel||data.role_kernel)msg.kernel=data.kernel||data.role_kernel;
      s.messages.push(msg);
      const preview=document.createElement('div');preview.innerHTML=displayMarkdown(result.summary);
      state(s,id,'已完成',preview.textContent.trim());
      if(!note)note=bubble(s,'天枢 · 收到团队回报','','progress');
      note.className='answer-text';note.innerHTML=displayMarkdown(names[id]+'：'+result.summary);
      showTeamReport(note,result);
      if(['CHAIN','COMP'].includes(id)&&result.chainGraph){
        const component=document.createElement('div');
        try{
          if(window.chainMap.mount(component,result.chainGraph)){
            s.feed.append(component);
            const save=document.createElement('button');save.className='btn btn-ghost';save.textContent='导出图谱 HTML';
            save.onclick=()=>{const url=URL.createObjectURL(new Blob([window.chainMap.fragment(result.chainGraph)],{type:'text/html;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='产业链图谱.html';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);};
            s.feed.append(save);
          }else progress(s,'图谱缺少有效层级或节点。');
        }catch{progress(s,'图谱数据格式不完整，已保留研究回报。');}
      }
    }catch(e){
      if(signal.aborted)throw e;
      s.messages.push({id:task_id,from:id,to:'TS',error:e.message});
      state(s,id,'失败',e.message);progress(s,names[id]+'任务失败：'+e.message);
    }
  }
  async function run(s){
    s.controller?.abort();
    const controller=new AbortController(), signal=controller.signal;
    s.controller=controller;s.phase='planning';s.plan=null;s.messages=[];s.agents=[];
    if(current===s)showPanel(s);
    s.snapshot=crypto.randomUUID();s.asOf=new Date().toISOString();
    s.materials=s.history.filter(m=>m.role==='user').slice();s.research=s.materials.map(m=>m.content).join('\n');
    try{
      progress(s,'正在识别研究标的、时间范围和统计口径。');
      const plan=parseJSON(await call(s,'TS','plan',context(s),signal));
      if(plan.type==='clarify'){
        const question=plan.question||'请补充企业全称或行业范围。';
        bubble(s,'天枢',question);s.history.push({role:'assistant',content:question});s.phase='clarify';if(current===s)showPanel(s);return;
      }
      if(!Object.hasOwn(teams,plan.type)||!plan.target||!plan.scope)throw Error('天枢未返回有效的标的和口径，请重试');
      s.plan=plan;s.phase='working';
      const ids=teams[plan.type];
      s.agents=ids.map(id=>({id,name:names[id],status:'等待中',task:['RC','RI'].includes(id)?'等待三个研究角色回报':'等待派发'}));
      progress(s,'已选择'+(plan.type==='company'?'企业':'行业')+'组 · '+plan.target+'。'+plan.scope);
      await Promise.all(ids.slice(0,3).map(id=>work(s,id,signal)));
      await work(s,ids[3],signal);
      s.phase='synthesizing';progress(s,'本组任务已结束，正在汇总回报与缺口。');
      await reply(s,'final',context(s),signal);s.phase='done';
    }catch(e){if(!signal.aborted){s.phase='failed';if(current===s)showPanel(s);bubble(s,'运行提示',e.message,'error');}}
  }
  async function handle(s,history){
    if(['idle','failed','clarify'].includes(s.phase)){void run(s);return;}
    const data=context(s,history);
    const choice=parseJSON(await call(s,'TS','steer',data));
    if(choice.action==='revise'){progress(s,'已收到范围调整，将按更新后的要求重新派单。');void run(s);return;}
    if(choice.action!=='answer')throw Error('未识别插话类型，请重新发送');
    await reply(s,'answer',{...context(s,history),latest_user_message:history.at(-1).content});
  }
  function send(){
    const s=current,text=input.value.trim();if(!text)return;
    if(location.protocol==='file:'){bubble(s,'启动提示','请使用项目内的“启动工作台.cmd”打开本地服务。','error');return;}
    let config;
    try{config=JSON.parse(localStorage.getItem('app.api.config'));}catch{}
    if(!config?.apiKey||!config.baseUrl||!config.model){bubble(s,'配置提示','请先在右上角设置中保存模型地址、API Key 和模型名，再发送。','error');return;}
    s.config=config;
    const chips=[...document.querySelectorAll('.cite-chip')];
    const content=text+(chips.length?'\n引用界面样例（仅作演示）：'+chips.map(c=>c.title).join('、'):'');
    chips.forEach(c=>c.querySelector('button').click());
    if(!s.history.length){
      s.item.dataset.fresh='0';
      s.item.dataset.name=text.slice(0,22);
      s.item.querySelector('.chat-name').textContent=s.item.dataset.name;
      $('#topbar-title').textContent=s.item.dataset.name;
    }
    input.value='';s.history.push({role:'user',content});
    bubble(s,'你',content,'user');
    const history=s.history.slice();
    s.queue=s.queue.then(()=>handle(s,history)).catch(e=>bubble(s,'消息处理失败',e.message,'error'));
  }
  $('.send').addEventListener('click',send);
  $('.circle-plus').title='导入带出处的指标数据（JSON）';
  $('.circle-plus').onclick=()=>{
    const s=current,picker=document.createElement('input');picker.type='file';picker.accept='.json';
    picker.onchange=async()=>{
      try{
        const file=picker.files[0];if(!file)return;
        if(file.size>1500000)throw Error('单个资料包请控制在 1.5 MB 内');
        const rows=JSON.parse((await file.text()).replace(/^\uFEFF/,''));
        if(rows?.type==='report'){
          if(!['FIN','IND'].includes(rows.role)||!rows.target||!rows.publisher||!/^https?:\/\//.test(rows.source)||!/^\d{4}-\d{2}-\d{2}$/.test(rows.published)||typeof rows.text!=='string'||!rows.text.trim()||rows.text.length>40000)throw Error('研报包需含标的、角色、发布方、原始链接、日期和不超过四万字的原文');
          s.report=rows;progress(s,'已载入研报原文，下次匹配该标的时将按页码和表名核验。');return;
        }
        if(!Array.isArray(rows)||!rows.every(r=>r&&r.target&&r.field&&r.source&&r.locator&&r.published&&r.unit&&Number.isInteger(r.year)&&Object.hasOwn(names,r.role)))throw Error('请使用指标接口说明中的记录数组格式');
        s.records=rows;
        progress(s,'已载入 '+file.name+'，共 '+rows.length+' 条记录，下次派单时匹配本次标的。');
      }catch(e){bubble(s,'导入失败',e.message,'error');}
    };picker.click();
  };
  $('#composer').addEventListener('submit',e=>{e.preventDefault();send();});
  input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.keyCode!==229){e.preventDefault();send();}});
})();
