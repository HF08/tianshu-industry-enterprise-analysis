Add-Type -AssemblyName System.Drawing

$refPath = $args[0]
$minePath = $args[1]
$cols = 16
$rows = 10

$refImg = [System.Drawing.Image]::FromFile($refPath)
$refBmp = New-Object System.Drawing.Bitmap($refImg)
$mineImg = [System.Drawing.Image]::FromFile($minePath)
$mineBmp = New-Object System.Drawing.Bitmap($mineImg)
$w = $mineBmp.Width; $h = $mineBmp.Height

$small = New-Object System.Drawing.Bitmap($w, $h)
$g = [System.Drawing.Graphics]::FromImage($small)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g.DrawImage($refBmp, (New-Object System.Drawing.Rectangle(0, 0, $w, $h)))
$g.Dispose()

$rect = New-Object System.Drawing.Rectangle(0, 0, $w, $h)
$dr = $small.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$rb = New-Object 'byte[]' ($dr.Stride * $h)
[System.Runtime.InteropServices.Marshal]::Copy($dr.Scan0, $rb, 0, $rb.Length)
$rstride = $dr.Stride
$small.UnlockBits($dr)

$dm = $mineBmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$mb = New-Object 'byte[]' ($dm.Stride * $h)
[System.Runtime.InteropServices.Marshal]::Copy($dm.Scan0, $mb, 0, $mb.Length)
$mstride = $dm.Stride
$mineBmp.UnlockBits($dm)

$cw = [int][math]::Floor($w / $cols)
$ch = [int][math]::Floor($h / $rows)
for ($cy = 0; $cy -lt $rows; $cy++) {
  $line = ""
  for ($cx = 0; $cx -lt $cols; $cx++) {
    $sum = 0.0; $n = 0
    for ($y = $cy * $ch; $y -lt ($cy + 1) * $ch; $y++) {
      $baseR = $y * $rstride
      $baseM = $y * $mstride
      for ($x = $cx * $cw; $x -lt ($cx + 1) * $cw; $x++) {
        $ir = $baseR + $x * 4
        $im = $baseM + $x * 4
        $sum += ([math]::Abs([int]$rb[$ir + 2] - [int]$mb[$im + 2]) + [math]::Abs([int]$rb[$ir + 1] - [int]$mb[$im + 1]) + [math]::Abs([int]$rb[$ir] - [int]$mb[$im])) / 3.0
        $n++
      }
    }
    $line += ("{0,4:N0}" -f ($sum / $n))
  }
  $line
}
$refBmp.Dispose(); $mineBmp.Dispose(); $refImg.Dispose(); $mineImg.Dispose()
