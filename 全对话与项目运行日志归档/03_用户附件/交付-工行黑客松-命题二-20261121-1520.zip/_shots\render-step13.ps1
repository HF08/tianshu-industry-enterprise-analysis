# 执行策略禁止直接运行 .ps1，用 scriptblock 执行（文件为 UTF-8 无 BOM，必须显式按 UTF-8 读取）：
# $s = [System.IO.File]::ReadAllText('D:\workSpaceForDSH\工行黑客松-命题二\_shots\render-step13.ps1', [System.Text.Encoding]::UTF8); & ([scriptblock]::Create($s))
$edge = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
$root = 'D:\workSpaceForDSH\工行黑客松-命题二'
$shots = "$root\_shots"
$base = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/_shots'
$profile = "$shots\edge-profile-step13"

$renderCommon = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=4000'
)

$testCommon = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=15000'
)

function Invoke-EdgeShot($shotPath, $url, $common) {
  $args = $common + "--screenshot=$shotPath" + $url
  Start-Process -FilePath $edge -ArgumentList $args -Wait -NoNewWindow | Out-Null
  if (-not (Test-Path $shotPath)) { throw "截图未生成：$shotPath" }
}

function Get-TestSummary($name, $url) {
  $domFile = "$shots\dom-$name.html"
  $errFile = "$shots\dom-$name.err"
  if (Test-Path $domFile) { Remove-Item -LiteralPath $domFile -Force }
  if (Test-Path $errFile) { Remove-Item -LiteralPath $errFile -Force }
  $args = $testCommon + '--dump-dom' + $url
  Start-Process -FilePath $edge -ArgumentList $args -Wait -NoNewWindow -RedirectStandardOutput $domFile -RedirectStandardError $errFile | Out-Null
  $dom = [System.IO.File]::ReadAllText($domFile, [System.Text.Encoding]::UTF8)
  if ($dom -notmatch '<div class="summary" id="summary">(.*?)</div>') { throw "$name 未找到测试汇总" }
  $summary = ($Matches[1] -replace '<[^>]+>', ' ').Trim() -replace '\s+', ' '
  $failCount = ([regex]::Matches($dom, 'class="status fail"')).Count
  if ($summary -notmatch '^ALL PASS') { throw "$name 未通过：$summary" }
  if ($failCount -ne 0) { throw "$name 存在 $failCount 条未通过断言" }
  Remove-Item -LiteralPath $domFile -Force
  Remove-Item -LiteralPath $errFile -Force
  return "$name：$summary"
}

# 出图：计算弹窗悬浮输入项、输入项来源详情带「← 返回」、弹窗内引用后的 chip
Invoke-EdgeShot "$shots\app-step13-calc-hover.png" "$base/shot-app-step13.html?state=calc-hover" $renderCommon
Invoke-EdgeShot "$shots\app-step13-nested.png" "$base/shot-app-step13.html?state=nested" $renderCommon
Invoke-EdgeShot "$shots\app-step13-cite.png" "$base/shot-app-step13.html?state=cite" $renderCommon

# 测试截图：第 13 步测试页
Invoke-EdgeShot "$shots\app-step13-test.png" "$base/test-app-step13.html" $testCommon

# 回归截图：第 6、8、9、10、11 步
Invoke-EdgeShot "$shots\app-step13-regress-step6.png" "$base/test-app-step6.html" $testCommon
Invoke-EdgeShot "$shots\app-step13-regress-step8.png" "$base/test-app-step8.html" $testCommon
Invoke-EdgeShot "$shots\app-step13-regress-step9.png" "$base/test-app-step9.html" $testCommon
Invoke-EdgeShot "$shots\app-step13-regress-step10.png" "$base/test-app-step10.html" $testCommon
Invoke-EdgeShot "$shots\app-step13-regress-step11.png" "$base/test-app-step11.html" $testCommon

Add-Type -AssemblyName System.Drawing
foreach ($n in 'app-step13-calc-hover.png', 'app-step13-nested.png', 'app-step13-cite.png', 'app-step13-test.png',
  'app-step13-regress-step6.png', 'app-step13-regress-step8.png', 'app-step13-regress-step9.png',
  'app-step13-regress-step10.png', 'app-step13-regress-step11.png') {
  $i = [System.Drawing.Image]::FromFile("$shots\$n")
  "$n $($i.Width)x$($i.Height)"
  $i.Dispose()
}

function Count-Color($path, $r, $g, $b, $x0, $y0, $x1, $y1) {
  $bmp = [System.Drawing.Bitmap]::FromFile($path)
  $count = 0
  for ($y = $y0; $y -lt $y1; $y += 1) {
    for ($x = $x0; $x -lt $x1; $x += 1) {
      $c = $bmp.GetPixel($x, $y)
      if ($c.R -eq $r -and $c.G -eq $g -and $c.B -eq $b) { $count += 1 }
    }
  }
  $bmp.Dispose()
  return $count
}

"计算弹窗悬浮小窗底色 #202023 像素数：$(Count-Color "$shots\app-step13-calc-hover.png" 32 32 35 400 100 1400 800)"
"来源详情弹窗底色 #1B1B1C 像素数：$(Count-Color "$shots\app-step13-nested.png" 27 27 28 400 100 1300 800)"
"引用 chip 底色 #3A3B3F 像素数（底部输入区）：$(Count-Color "$shots\app-step13-cite.png" 58 59 63 290 640 1400 890)"

Get-TestSummary 'step13' "$base/test-app-step13.html"
Get-TestSummary 'step10' "$base/test-app-step10.html"
Get-TestSummary 'step11' "$base/test-app-step11.html"
Get-TestSummary 'step6' "$base/test-app-step6.html"
Get-TestSummary 'step8' "$base/test-app-step8.html"
Get-TestSummary 'step9' "$base/test-app-step9.html"
