Add-Type -AssemblyName System.Drawing

$refPath = $args[0]
$refScale = [double]$args[1]
$minePath = $args[2]
$mineScale = [double]$args[3]

function LoadBuf($path) {
  $img = [System.Drawing.Image]::FromFile($path)
  $bmp = New-Object System.Drawing.Bitmap($img)
  $pw = [int]$bmp.Width; $ph = [int]$bmp.Height
  $rect = New-Object System.Drawing.Rectangle(0, 0, $pw, $ph)
  $data = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $buf = New-Object 'byte[]' ($data.Stride * $ph)
  [System.Runtime.InteropServices.Marshal]::Copy($data.Scan0, $buf, 0, $buf.Length)
  $stride = $data.Stride
  $bmp.UnlockBits($data)
  $img.Dispose(); $bmp.Dispose()
  return @{ Buf = $buf; Stride = $stride; W = $pw; H = $ph }
}

$ref = LoadBuf $refPath
$mine = LoadBuf $minePath

function ExtentInk($img, [double]$scale, [double]$x0, [double]$y0, [double]$x1, [double]$y1, [int]$thr) {
  $buf = $img.Buf; $stride = $img.Stride
  $ix0 = [int][math]::Round($x0 * $scale); $ix1 = [int][math]::Round($x1 * $scale)
  $iy0 = [int][math]::Round($y0 * $scale); $iy1 = [int][math]::Round($y1 * $scale)
  if ($ix1 -gt $img.W) { $ix1 = $img.W }
  if ($iy1 -gt $img.H) { $iy1 = $img.H }
  $minX = 99999; $maxX = -1; $minY = 99999; $maxY = -1
  for ($y = $iy0; $y -lt $iy1; $y++) {
    for ($x = $ix0; $x -lt $ix1; $x++) {
      $i = $y * $stride + $x * 4
      if (0.299 * $buf[$i + 2] + 0.587 * $buf[$i + 1] + 0.114 * $buf[$i] -gt $thr) {
        if ($x -lt $minX) { $minX = $x }
        if ($x -gt $maxX) { $maxX = $x }
        if ($y -lt $minY) { $minY = $y }
        if ($y -gt $maxY) { $maxY = $y }
      }
    }
  }
  if ($maxX -lt 0) { return @($null, $null, $null, $null) }
  return @([math]::Round($minX / $scale, 1), [math]::Round($maxX / $scale, 1), [math]::Round($minY / $scale, 1), [math]::Round($maxY / $scale, 1))
}

$fmt = "{0,-12} ref x{1,7}..{2,-7} y{3,7}..{4,-7} | mine x{5,7}..{6,-7} y{7,7}..{8,-7} | dx{9,6} dy{10,6}"
foreach ($line in $args[4..($args.Count - 1)]) {
  $p = $line.Split(' ')
  $name = $p[0]
  $x0 = [double]$p[1]; $y0 = [double]$p[2]; $x1 = [double]$p[3]; $y1 = [double]$p[4]
  $a = ExtentInk $ref $refScale $x0 $y0 $x1 $y1 92
  $b = ExtentInk $mine $mineScale $x0 $y0 $x1 $y1 92
  if ($null -eq $a[0]) { $ax0 = 0; $ax1 = 0; $ay0 = 0; $ay1 = 0 } else { $ax0 = $a[0]; $ax1 = $a[1]; $ay0 = $a[2]; $ay1 = $a[3] }
  if ($null -eq $b[0]) { $bx0 = 0; $bx1 = 0; $by0 = 0; $by1 = 0 } else { $bx0 = $b[0]; $bx1 = $b[1]; $by0 = $b[2]; $by1 = $b[3] }
  $fmt -f $name, $ax0, $ax1, $ay0, $ay1, $bx0, $bx1, $by0, $by1, [math]::Round($bx0 - $ax0, 1), [math]::Round($by0 - $ay0, 1)
}
