Add-Type -AssemblyName System.Drawing

$imgPath = $args[0]
$scale = [double]$args[1]
$label = $args[2]

$img = [System.Drawing.Image]::FromFile($imgPath)
$bmp = New-Object System.Drawing.Bitmap($img)
$pw = [int]$bmp.Width; $ph = [int]$bmp.Height
$rect = New-Object System.Drawing.Rectangle(0, 0, $pw, $ph)
$data = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$stride = $data.Stride
$buf = New-Object 'byte[]' ($stride * $ph)
[System.Runtime.InteropServices.Marshal]::Copy($data.Scan0, $buf, 0, $buf.Length)
$bmp.UnlockBits($data)
$img.Dispose()
$bmp.Dispose()

$cw = [math]::Round($pw / $scale)
$ch = [math]::Round($ph / $scale)

function Px([double]$css) { [int][math]::Round($css * $scale) }
function Idx([int]$x, [int]$y) { return $y * $stride + $x * 4 }
function Red([int]$x, [int]$y) { return $buf[(Idx $x $y) + 2] }
function Grn([int]$x, [int]$y) { return $buf[(Idx $x $y) + 1] }
function Blu([int]$x, [int]$y) { return $buf[(Idx $x $y)] }

function ColRuns([double]$cssX, [double]$cssY0, [double]$cssY1, [int]$tol) {
  $x = Px $cssX
  if ($x -ge $pw) { $x = $pw - 1 }
  $y0 = Px $cssY0; $y1 = Px $cssY1
  if ($y1 -gt $ph) { $y1 = $ph }
  $pr = Red $x $y0; $pg = Grn $x $y0; $pb = Blu $x $y0
  $sr = $pr; $sg = $pg; $sbb = $pb
  $start = $y0
  for ($y = $y0 + 1; $y -lt $y1; $y++) {
    $cr = Red $x $y; $cg = Grn $x $y; $cb = Blu $x $y
    $d = [math]::Abs($cr - $pr) + [math]::Abs($cg - $pg) + [math]::Abs($cb - $pb)
    if ($d -gt $tol) {
      "{0,8}-{1,8}  {2:X2}{3:X2}{4:X2}" -f [math]::Round($start / $scale, 2), [math]::Round(($y - 1) / $scale, 2), $sr, $sg, $sbb
      $start = $y
      $sr = $cr; $sg = $cg; $sbb = $cb
    }
    $pr = $cr; $pg = $cg; $pb = $cb
  }
  "{0,8}-{1,8}  {2:X2}{3:X2}{4:X2}" -f [math]::Round($start / $scale, 2), [math]::Round(($y1 - 1) / $scale, 2), $sr, $sg, $sbb
}

function RowRuns([double]$cssY, [double]$cssX0, [double]$cssX1, [int]$tol) {
  $y = Px $cssY
  if ($y -ge $ph) { $y = $ph - 1 }
  $x0 = Px $cssX0; $x1 = Px $cssX1
  if ($x1 -gt $pw) { $x1 = $pw }
  $pr = Red $x0 $y; $pg = Grn $x0 $y; $pb = Blu $x0 $y
  $sr = $pr; $sg = $pg; $sbb = $pb
  $start = $x0
  for ($x = $x0 + 1; $x -lt $x1; $x++) {
    $cr = Red $x $y; $cg = Grn $x $y; $cb = Blu $x $y
    $d = [math]::Abs($cr - $pr) + [math]::Abs($cg - $pg) + [math]::Abs($cb - $pb)
    if ($d -gt $tol) {
      "{0,8}-{1,8}  {2:X2}{3:X2}{4:X2}" -f [math]::Round($start / $scale, 2), [math]::Round(($x - 1) / $scale, 2), $sr, $sg, $sbb
      $start = $x
      $sr = $cr; $sg = $cg; $sbb = $cb
    }
    $pr = $cr; $pg = $cg; $pb = $cb
  }
  "{0,8}-{1,8}  {2:X2}{3:X2}{4:X2}" -f [math]::Round($start / $scale, 2), [math]::Round(($x1 - 1) / $scale, 2), $sr, $sg, $sbb
}

function InkBands([double]$cssX0, [double]$cssX1, [int]$thr, [int]$step) {
  $x0 = Px $cssX0; $x1 = Px $cssX1
  if ($x1 -gt $pw) { $x1 = $pw }
  $counts = New-Object 'int[]' $ph
  for ($y = 0; $y -lt $ph; $y++) {
    $n = 0
    for ($x = $x0; $x -lt $x1; $x += $step) {
      $i = Idx $x $y
      if (0.299 * $buf[$i + 2] + 0.587 * $buf[$i + 1] + 0.114 * $buf[$i] -gt $thr) { $n++ }
    }
    $counts[$y] = $n
  }
  $y = 0
  while ($y -lt $ph) {
    if ($counts[$y] -gt 0) {
      $s = $y; $max = 0; $gap = 0
      while ($y -lt $ph -and ($counts[$y] -gt 0 -or $gap -le 2)) {
        if ($counts[$y] -gt 0) { $gap = 0; if ($counts[$y] -gt $max) { $max = $counts[$y] } } else { $gap++ }
        $y++
      }
      $e = $y - $gap - 1
      if (($e - $s) -ge 1) { "  {0,8}-{1,8}  w={2,6}  ink={3}" -f [math]::Round($s / $scale, 1), [math]::Round($e / $scale, 1), [math]::Round(($e - $s) / $scale, 1), $max }
    } else { $y++ }
  }
}

Write-Output "===== $label  CSS ${cw}x${ch}  scale=$scale ====="
foreach ($op in $args[3..($args.Count - 1)]) {
  $parts = $op.Split(':')
  $kind = $parts[0]
  if ($kind -eq 'I') {
    Write-Output "--- INK x $($parts[1])..$($parts[2]) thr=$($parts[3])"
    InkBands ([double]$parts[1]) ([double]$parts[2]) ([int]$parts[3]) 2
  } elseif ($kind -eq 'C') {
    Write-Output "--- COL x=$($parts[1]) y $($parts[2])..$($parts[3]) tol=$($parts[4])"
    ColRuns ([double]$parts[1]) ([double]$parts[2]) ([double]$parts[3]) ([int]$parts[4])
  } elseif ($kind -eq 'R') {
    Write-Output "--- ROW y=$($parts[1]) x $($parts[2])..$($parts[3]) tol=$($parts[4])"
    RowRuns ([double]$parts[1]) ([double]$parts[2]) ([double]$parts[3]) ([int]$parts[4])
  } elseif ($kind -eq 'E') {
    $y0 = Px ([double]$parts[1]); $y1 = Px ([double]$parts[2])
    $x0 = Px ([double]$parts[3]); $x1 = Px ([double]$parts[4])
    $minX = $pw; $maxX = 0
    $minY = $ph; $maxY = 0
    for ($y = $y0; $y -lt $y1; $y++) {
      for ($x = $x0; $x -lt $x1; $x++) {
        $i = Idx $x $y
        if (0.299 * $buf[$i + 2] + 0.587 * $buf[$i + 1] + 0.114 * $buf[$i] -gt 92) {
          if ($x -lt $minX) { $minX = $x }
          if ($x -gt $maxX) { $maxX = $x }
          if ($y -lt $minY) { $minY = $y }
          if ($y -gt $maxY) { $maxY = $y }
        }
      }
    }
    "--- EXTENT y $($parts[1])..$($parts[2]) x $($parts[3])..$($parts[4]) => x {0}..{1}  y {2}..{3}" -f [math]::Round($minX / $scale, 1), [math]::Round($maxX / $scale, 1), [math]::Round($minY / $scale, 1), [math]::Round($maxY / $scale, 1)
  } elseif ($kind -eq 'X') {
    $x0 = Px ([double]$parts[1]); $y0 = Px ([double]$parts[2])
    $x1 = Px ([double]$parts[3]); $y1 = Px ([double]$parts[4])
    $best = 0; $br = 0; $bg = 0; $bb = 0
    $lums = New-Object 'System.Collections.Generic.List[double]'
    for ($y = $y0; $y -lt $y1; $y++) {
      for ($x = $x0; $x -lt $x1; $x++) {
        $i = Idx $x $y
        $l = 0.299 * $buf[$i + 2] + 0.587 * $buf[$i + 1] + 0.114 * $buf[$i]
        $lums.Add($l)
        if ($l -gt $best) { $best = $l; $br = $buf[$i + 2]; $bg = $buf[$i + 1]; $bb = $buf[$i] }
      }
    }
    $arr = $lums.ToArray(); [array]::Sort($arr)
    $p95 = $arr[[int]($arr.Length * 0.95)]
    $p99 = $arr[[int]($arr.Length * 0.99)]
    "--- PEAK x $($parts[1])..$($parts[3]) y $($parts[2])..$($parts[4]) => max {0:X2}{1:X2}{2:X2} lum95={3:N0} lum99={4:N0}" -f $br, $bg, $bb, $p95, $p99
  } elseif ($kind -eq 'M') {
    $x0 = Px ([double]$parts[1]); $x1 = Px ([double]$parts[2])
    $y0 = Px ([double]$parts[3]); $y1 = Px ([double]$parts[4])
    $s = ''
    $ruler = ''
    for ($x = $x0; $x -lt $x1; $x++) {
      $hit = $false
      for ($y = $y0; $y -lt $y1; $y++) {
        $i = Idx $x $y
        if (0.299 * $buf[$i + 2] + 0.587 * $buf[$i + 1] + 0.114 * $buf[$i] -gt 92) { $hit = $true; break }
      }
      $s += $(if ($hit) { '#' } else { '.' })
    }
    $css0 = [math]::Round($x0 / $scale)
    for ($k = 0; $k -lt $s.Length; $k += 10) { $ruler += ('{0,-10}' -f ([math]::Round(($x0 + $k) / $scale) % 1000)) }
    "--- MAP x $($parts[1])..$($parts[2]) y $($parts[3])..$($parts[4]) start=$css0"
    $ruler
    $s
  } elseif ($kind -eq 'P') {
    $x = Px ([double]$parts[1]); $y = Px ([double]$parts[2])
    "{0,8};{1,8}  {2:X2}{3:X2}{4:X2}" -f $parts[1], $parts[2], (Red $x $y), (Grn $x $y), (Blu $x $y)
  }
}
