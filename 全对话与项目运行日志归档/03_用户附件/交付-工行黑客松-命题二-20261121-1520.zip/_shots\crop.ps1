Add-Type -AssemblyName System.Drawing

$imgPath = $args[0]
$scale = [double]$args[1]
$out = $args[2]
$cx = [double]$args[3]
$cy = [double]$args[4]
$cwd = [double]$args[5]
$chh = [double]$args[6]
$zoom = [double]$args[7]

$img = [System.Drawing.Image]::FromFile($imgPath)
$bmp = New-Object System.Drawing.Bitmap($img)

$x = [int][math]::Round($cx * $scale)
$y = [int][math]::Round($cy * $scale)
$w = [int][math]::Round($cwd * $scale)
$h = [int][math]::Round($chh * $scale)
if ($x -lt 0) { $x = 0 }
if ($y -lt 0) { $y = 0 }
if ($x + $w -gt $bmp.Width) { $w = $bmp.Width - $x }
if ($y + $h -gt $bmp.Height) { $h = $bmp.Height - $y }

$dst = New-Object System.Drawing.Bitmap([int]($w * $zoom), [int]($h * $zoom))
$g = [System.Drawing.Graphics]::FromImage($dst)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
$g.DrawImage($bmp, (New-Object System.Drawing.Rectangle(0, 0, [int]($w * $zoom), [int]($h * $zoom))), (New-Object System.Drawing.Rectangle($x, $y, $w, $h)), [System.Drawing.GraphicsUnit]::Pixel)
$g.Dispose()
$dst.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
$dst.Dispose()
$img.Dispose()
$bmp.Dispose()
Write-Output "saved $out  crop css=($cx,$cy,$cwd,$chh) zoom=$zoom"
