$edge = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
$root = 'D:\workSpaceForDSH\工行黑客松-命题二'
$shots = "$root\_shots"
$app = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/app/index.html'
$base = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/_shots'
$profile = "$shots\edge-profile-step8"

$common = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=3000'
)

& $edge @common "--screenshot=$shots\app-step8-closed.png" $app | Out-Null
& $edge @common "--screenshot=$shots\app-step8-open.png" "$base/shot-app-step8-expanded.html" | Out-Null

$testCommon = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=8000'
)
& $edge @testCommon "--screenshot=$shots\app-step8-test.png" "$base/test-app-step8.html" | Out-Null

Add-Type -AssemblyName System.Drawing
foreach ($n in 'app-step8-closed.png', 'app-step8-open.png', 'app-step8-test.png') {
  $i = [System.Drawing.Image]::FromFile("$shots\$n")
  "$n $($i.Width)x$($i.Height)"
  $i.Dispose()
}

# 在对话框行上扫描 #2C2C2E，取左右边缘，核对收起 1104 与展开 988
foreach ($n in 'app-step8-closed.png', 'app-step8-open.png') {
  $bmp = [System.Drawing.Bitmap]::FromFile("$shots\$n")
  $target = [System.Drawing.Color]::FromArgb(44, 44, 46)
  $lefts = @()
  $rights = @()
  foreach ($y in 790, 800, 810) {
    $xs = @()
    for ($x = 0; $x -lt $bmp.Width; $x += 1) {
      $c = $bmp.GetPixel($x, $y)
      if ($c.R -eq 44 -and $c.G -eq 44 -and $c.B -eq 46) { $xs += $x }
    }
    if ($xs.Count -gt 0) {
      $lefts += ($xs | Measure-Object -Minimum).Minimum
      $rights += ($xs | Measure-Object -Maximum).Maximum
    }
  }
  $left = ($lefts | Measure-Object -Minimum).Minimum
  $right = ($rights | Measure-Object -Maximum).Maximum
  $panelPixel = $bmp.GetPixel(1690, 400)
  # 扫描只匹配内部底色 #2C2C2E，左右各含 1px 边框 #38383C，外宽 = 内宽 + 2
  "$n 对话框 x=$left..$right 内宽 $($right - $left + 1) 外宽 $($right - $left + 3) / 右侧 (1690,400) = $($panelPixel.R),$($panelPixel.G),$($panelPixel.B)"
  $bmp.Dispose()
}
