$edge = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
$root = 'D:\workSpaceForDSH\工行黑客松-命题二'
$shots = "$root\_shots"
$base = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/_shots'
$profile = "$shots\edge-profile-step10"

$renderCommon = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=4000'
)

& $edge @renderCommon "--screenshot=$shots\app-step10-report.png" "$base/shot-app-step10-report.html" | Out-Null
& $edge @renderCommon "--screenshot=$shots\app-step10-hover.png" "$base/shot-app-step10-hover.html" | Out-Null

$testCommon = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=8000'
)

& $edge @testCommon "--screenshot=$shots\app-step10-test.png" "$base/test-app-step10.html" | Out-Null

Add-Type -AssemblyName System.Drawing
foreach ($n in 'app-step10-report.png', 'app-step10-hover.png', 'app-step10-test.png') {
  $i = [System.Drawing.Image]::FromFile("$shots\$n")
  "$n $($i.Width)x$($i.Height)"
  $i.Dispose()
}

# 在 y=400 扫描报告面板底色 #1B1B1C 的左右边缘，核对面板宽 1160（两侧各 1px 边框）
$bmp = [System.Drawing.Bitmap]::FromFile("$shots\app-step10-report.png")
$xs = @()
for ($x = 0; $x -lt $bmp.Width; $x += 1) {
  $c = $bmp.GetPixel($x, 400)
  if ($c.R -eq 27 -and $c.G -eq 27 -and $c.B -eq 28) { $xs += $x }
}
if ($xs.Count -gt 0) {
  $left = ($xs | Measure-Object -Minimum).Minimum
  $right = ($xs | Measure-Object -Maximum).Maximum
  "报告面板内宽 $($right - $left + 1)，外宽 $($right - $left + 3)，左边缘 x=$left"
} else {
  '报告面板底色未在 y=400 命中'
}
$bmp.Dispose()

# 回归：第 6、8、9 步测试页在改动后的页面上重跑，结果页截图用于核对
& $edge @testCommon "--screenshot=$shots\app-step10-regress-step6.png" "$base/test-app-step6.html" | Out-Null
& $edge @testCommon "--screenshot=$shots\app-step10-regress-step8.png" "$base/test-app-step8.html" | Out-Null
& $edge @testCommon "--screenshot=$shots\app-step10-regress-step9.png" "$base/test-app-step9.html" | Out-Null

foreach ($n in 'app-step10-regress-step6.png', 'app-step10-regress-step8.png', 'app-step10-regress-step9.png') {
  $i = [System.Drawing.Image]::FromFile("$shots\$n")
  "$n $($i.Width)x$($i.Height)"
  $i.Dispose()
}
