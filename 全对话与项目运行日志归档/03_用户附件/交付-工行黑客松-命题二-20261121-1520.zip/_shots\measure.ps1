Add-Type -AssemblyName System.Drawing

function Get-Runs {
  param($bmp, $fixed, $along, $vertical, $minLen)
  $runs = @()
  $prev = $null
  $start = 0
  $len = if ($vertical) { $bmp.Height } else { $bmp.Width }
  for ($i = 0; $i -lt $len; $i++) {
    $x = if ($vertical) { $fixed } else { $i }
    $y = if ($vertical) { $i } else { $fixed }
    $c = $bmp.GetPixel($x, $y)
    $key = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
    if ($key -ne $prev) {
      if ($null -ne $prev -and ($i - $start) -ge $minLen) { $runs += [pscustomobject]@{ Start = $start; End = $i - 1; Color = $prev } }
      $prev = $key
      $start = $i
    }
  }
  if (($len - $start) -ge $minLen) { $runs += [pscustomobject]@{ Start = $start; End = $len - 1; Color = $prev } }
  $runs
}

function Show-Image {
  param($path, $label)
  $img = [System.Drawing.Image]::FromFile($path)
  $bmp = New-Object System.Drawing.Bitmap($img)
  $w = $bmp.Width; $h = $bmp.Height
  Write-Output "===== $label  ${w}x${h} ====="
  $colX = [int]($w * 0.05)
  Write-Output "--- 列扫描 x=$colX（侧栏内部，找按钮与选中行）---"
  Get-Runs -bmp $bmp -fixed $colX -vertical $true -minLen 10 |
    ForEach-Object { "{0,5}-{1,5}  {2}  {3,6:N1}%  {4,6:N1}%" -f $_.Start, $_.End, $_.Color, ($_.Start / $h * 100), ($_.End / $h * 100) }
  $rowY = [int]($h * 0.55)
  Write-Output "--- 行扫描 y=$rowY（找侧栏边界）---"
  Get-Runs -bmp $bmp -fixed $rowY -vertical $false -minLen 6 |
    Select-Object -First 12 |
    ForEach-Object { "{0,5}-{1,5}  {2}  {3,6:N1}%  {4,6:N1}%" -f $_.Start, $_.End, $_.Color, ($_.Start / $w * 100), ($_.End / $w * 100) }
  $colX2 = [int]($w * 0.5)
  Write-Output "--- 列扫描 x=$colX2（主区中线，找入口与输入框）---"
  Get-Runs -bmp $bmp -fixed $colX2 -vertical $true -minLen 8 |
    ForEach-Object { "{0,5}-{1,5}  {2}  {3,6:N1}%" -f $_.Start, $_.End, $_.Color, ($_.Start / $h * 100) }
  $img.Dispose()
  $bmp.Dispose()
}

Show-Image 'C:\Users\13826\.dsh\attachments\v1\objects\c8\c80a6c5b6a96d9a73565c978cd09fab87a1d884af331f6866681ead7040cef2b' '原-初始'
Show-Image 'D:\workSpaceForDSH\工行黑客松-命题二\_shots\initial.png' '我-初始'
Show-Image 'C:\Users\13826\.dsh\attachments\v1\objects\10\1064311953972e36849e9c6802fac4a863b03d808b5b08149a681266dbfa63e6' '原-会话'
Show-Image 'D:\workSpaceForDSH\工行黑客松-命题二\_shots\session.png' '我-会话'
