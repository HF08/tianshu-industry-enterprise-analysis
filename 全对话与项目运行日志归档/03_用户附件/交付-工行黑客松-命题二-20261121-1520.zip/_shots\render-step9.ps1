$edge = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
$root = 'D:\workSpaceForDSH\工行黑客松-命题二'
$shots = "$root\_shots"
$app = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/app/index.html'
$base = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/_shots'
$profile = "$shots\edge-profile-step9"

$common = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=3000'
)

& $edge @common "--screenshot=$shots\app-step9.png" $app | Out-Null

$testCommon = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=8000'
)
& $edge @testCommon "--screenshot=$shots\app-step9-test.png" "$base/test-app-step9.html" | Out-Null

Add-Type -AssemblyName System.Drawing
foreach ($n in 'app-step9.png', 'app-step9-test.png') {
  $i = [System.Drawing.Image]::FromFile("$shots\$n")
  "$n $($i.Width)x$($i.Height)"
  $i.Dispose()
}

# 在 y=400 扫描：左栏右分隔线位置与主区起点，核对左栏 300
$bmp = [System.Drawing.Bitmap]::FromFile("$shots\app-step9.png")
$border = @()
for ($x = 280; $x -lt 320; $x += 1) {
  $c = $bmp.GetPixel($x, 400)
  if ($c.R -eq 64 -and $c.G -eq 64 -and $c.B -eq 64) { $border += $x }
}
"左栏分隔线 x=$($border -join ',')"
# 面板上边线 rgba(232,232,232,.14) 叠在 #1B1B1C 上 ≈ rgb(56,56,57)
$rule = @()
for ($y = 700; $y -lt 890; $y += 1) {
  $c = $bmp.GetPixel(150, $y)
  if ($c.R -eq 56 -and $c.G -eq 56 -and $c.B -eq 57) { $rule += $y }
}
"面板分隔线 y=$($rule -join ',')"
$bmp.Dispose()
