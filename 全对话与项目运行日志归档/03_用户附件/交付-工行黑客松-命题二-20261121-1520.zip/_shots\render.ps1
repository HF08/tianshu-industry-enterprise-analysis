$edge = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
$root = 'D:\workSpaceForDSH\工行黑客松-命题二'
$shots = "$root\_shots"
$url = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/preview/01-main-gui.html'
$profile = "$shots\edge-profile"

$common = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  "--user-data-dir=$profile", '--force-device-scale-factor=1', '--window-size=1696,890',
  '--virtual-time-budget=2500'
)

& $edge @common "--screenshot=$shots\initial.png" $url | Out-Null
& $edge @common "--screenshot=$shots\session.png" "${url}?state=session" | Out-Null

Add-Type -AssemblyName System.Drawing
foreach ($n in 'initial.png', 'session.png') {
  $i = [System.Drawing.Image]::FromFile("$shots\$n")
  "$n $($i.Width)x$($i.Height)"
  $i.Dispose()
}
