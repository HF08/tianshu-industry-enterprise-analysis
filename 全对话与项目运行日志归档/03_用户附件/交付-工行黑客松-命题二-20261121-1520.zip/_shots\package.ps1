$root = 'D:\workSpaceForDSH\工行黑客松-命题二'
$stage = 'D:\workSpaceForDSH\_交付暂存-工行黑客松-命题二'
$zip = 'D:\workSpaceForDSH\交付-工行黑客松-命题二-20261121-1101.zip'

if ($stage -ne 'D:\workSpaceForDSH\_交付暂存-工行黑客松-命题二') { throw '暂存路径不符' }
if ($zip -ne 'D:\workSpaceForDSH\交付-工行黑客松-命题二-20261121-1101.zip') { throw '压缩包路径不符' }

if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Path $stage | Out-Null

Copy-Item "$root\app" -Destination $stage -Recurse
Copy-Item "$root\preview" -Destination $stage -Recurse
Copy-Item "$root\README-接手说明.md" -Destination $stage
Copy-Item "$root\交接报告.md" -Destination $stage
Copy-Item "$root\待办清单.md" -Destination $stage
Copy-Item "$root\启动应用.cmd" -Destination $stage

New-Item -ItemType Directory -Path "$stage\_shots" | Out-Null
Get-ChildItem "$root\_shots" -File | Copy-Item -Destination "$stage\_shots"

if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path "$stage\*" -DestinationPath $zip -CompressionLevel Optimal

Remove-Item $stage -Recurse -Force

$item = Get-Item $zip
"压缩包：{0}" -f $item.FullName
"大小：{0:N2} MB" -f ($item.Length / 1MB)
Add-Type -AssemblyName System.IO.Compression.FileSystem
$a = [System.IO.Compression.ZipFile]::OpenRead($zip)
"条目数：{0}" -f $a.Entries.Count
$a.Entries | Select-Object -First 15 FullName | ForEach-Object { "  " + $_.FullName }
$a.Dispose()
