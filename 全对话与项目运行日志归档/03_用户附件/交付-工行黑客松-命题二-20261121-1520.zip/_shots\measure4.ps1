Add-Type -AssemblyName System.Drawing

$imgPath = $args[0]
$scale = [double]$args[1]
$label = $args[2]
$sbw = [double]$args[3]

$img = [System.Drawing.Image]::FromFile($imgPath)
$bmp = New-Object System.Drawing.Bitmap($img)
$pw = $bmp.Width; $ph = $bmp.Height
$cw = [math]::Round($pw / $scale); $ch = [math]::Round($ph / $scale)
$sbPx = [int][math]::Round($sbw * $scale)

function IsInk($c) { (0.299 * $c.R + 0.587 * $c.G + 0.114 * $c.B) -gt 90 }

function Bands($x0, $x1) {
  $rows = New-Object 'bool[]' $ph
  $counts = New-Object 'int[]' $ph
  for ($y = 0; $y -lt $ph; $y++) {
    $n = 0
    for ($x = $x0; $x -lt $x1; $x++) { if (IsInk($bmp.GetPixel($x, $y))) { $n++ } }
    $counts[$y] = $n
    $rows[$y] = $n -gt 0
  }
  $bands = @()
  $y = 0
  while ($y -lt $ph) {
    if ($rows[$y]) {
      $s = $y; $max = 0; $gap = 0
      while ($y -lt $ph -and ($rows[$y] -or $gap -le 2)) {
        if ($rows[$y]) { $gap = 0; if ($counts[$y] -gt $max) { $max = $counts[$y] } } else { $gap++ }
        $y++
      }
      $e = $y - $gap - 1
      if (($e - $s) -ge 1) { $bands += [pscustomobject]@{ S = [math]::Round($s / $scale); E = [math]::Round($e / $scale); N = $max } }
    } else { $y++ }
  }
  $bands
}

function ColorRuns($yCss) {
  $y = [int][math]::Round($yCss * $scale)
  if ($y -ge $ph) { $y = $ph - 1 }
  $prev = $null; $start = 0; $runs = @()
  for ($x = 0; $x -lt $pw; $x++) {
    $c = $bmp.GetPixel($x, $y)
    $key = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
    if ($key -ne $prev) {
      if ($null -ne $prev -and ($x - $start) -ge 4) { $runs += [pscustomobject]@{ A = [math]::Round($start / $scale); B = [math]::Round(($x - 1) / $scale); C = $prev } }
      $prev = $key; $start = $x
    }
  }
  $runs
}

Write-Output "===== $label  CSS ${cw}x${ch} ====="
Write-Output "SIDEBAR INK BANDS"
Bands 0 $sbPx | ForEach-Object { "  {0,4}-{1,4}  ink={2}" -f $_.S, $_.E, $_.N }
Write-Output "MAIN INK BANDS"
Bands $sbPx $pw | ForEach-Object { "  {0,4}-{1,4}  ink={2}" -f $_.S, $_.E, $_.N }
Write-Output "ROW COLOR RUNS y=520"
ColorRuns 520 | ForEach-Object { "  {0,4}-{1,4}  {2}" -f $_.A, $_.B, $_.C }
Write-Output "ROW COLOR RUNS y=760"
ColorRuns 760 | ForEach-Object { "  {0,4}-{1,4}  {2}" -f $_.A, $_.B, $_.C }

$img.Dispose()
$bmp.Dispose()
