Add-Type -AssemblyName System.Drawing

$imgPath = $args[0]
$scale = [double]$args[1]
$label = $args[2]

$img = [System.Drawing.Image]::FromFile($imgPath)
$bmp = New-Object System.Drawing.Bitmap($img)
$pw = $bmp.Width; $ph = $bmp.Height
$cw = [math]::Round($pw / $scale); $ch = [math]::Round($ph / $scale)

function HexAt($cssX, $cssY) {
  $x = [int][math]::Round($cssX * $scale)
  $y = [int][math]::Round($cssY * $scale)
  if ($x -ge $pw) { $x = $pw - 1 }
  if ($y -ge $ph) { $y = $ph - 1 }
  $c = $bmp.GetPixel($x, $y)
  "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
}

Write-Output "===== $label  CSS ${cw}x${ch}  scale=$scale ====="
Write-Output "POINTS"
foreach ($p in @(
  @(20, 118), @(20, 100), @(20, 410), @(20, 470), @(200, 250),
  @(500, 200), @(1000, 200), @(1000, 700), @(1000, 830),
  @(1000, 30), @(1000, 330), @(1000, 500), @(20, 640), @(20, 760)
)) {
  $hx = HexAt $p[0] $p[1]
  Write-Output ("  ({0,5},{1,5})  {2}" -f $p[0], $p[1], $hx)
}

Write-Output "COLUMN x=20 CSS (button and row bands)"
$x = [int][math]::Round(20 * $scale)
$prev = $null; $start = 0; $runs = @()
for ($y = 0; $y -lt $ph; $y++) {
  $c = $bmp.GetPixel($x, $y)
  $key = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
  if ($key -ne $prev) {
    if ($null -ne $prev -and ($y - $start) -ge 6) { $runs += [pscustomobject]@{ A = [math]::Round($start / $scale); B = [math]::Round(($y - 1) / $scale); C = $prev } }
    $prev = $key; $start = $y
  }
}
$runs | ForEach-Object { "  {0,4}-{1,4}  {2}" -f $_.A, $_.B, $_.C }

Write-Output "ROW y=25% CSS (sidebar edge)"
$y = [int][math]::Round(0.25 * $ph)
$prev = $null; $start = 0; $runs = @()
for ($x2 = [int][math]::Round(330 * $scale); $x2 -lt [int][math]::Round(400 * $scale); $x2++) {
  $c = $bmp.GetPixel($x2, $y)
  $key = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
  if ($key -ne $prev) {
    if ($null -ne $prev -and ($x2 - $start) -ge 1) { $runs += [pscustomobject]@{ A = [math]::Round($start / $scale); B = [math]::Round(($x2 - 1) / $scale); C = $prev } }
    $prev = $key; $start = $x2
  }
}
$runs | ForEach-Object { "  {0,4}-{1,4}  {2}" -f $_.A, $_.B, $_.C }

$img.Dispose()
$bmp.Dispose()
