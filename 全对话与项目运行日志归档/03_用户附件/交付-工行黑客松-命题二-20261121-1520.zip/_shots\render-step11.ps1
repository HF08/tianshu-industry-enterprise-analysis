# 执行策略禁止直接运行 .ps1，用 scriptblock 执行（文件为 UTF-8 无 BOM，必须显式按 UTF-8 读取）：
# $s = [System.IO.File]::ReadAllText('D:\workSpaceForDSH\工行黑客松-命题二\_shots\render-step11.ps1', [System.Text.Encoding]::UTF8); & ([scriptblock]::Create($s))
$edge = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
$root = 'D:\workSpaceForDSH\工行黑客松-命题二'
$shots = "$root\_shots"
$base = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/_shots'
$profile = "$shots\edge-profile-step11"

$renderCommon = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=4000'
)

& $edge @renderCommon "--screenshot=$shots\app-step11-menu.png" "$base/shot-app-step11.html?state=menu" | Out-Null
& $edge @renderCommon "--screenshot=$shots\app-step11-source.png" "$base/shot-app-step11.html?state=source" | Out-Null
& $edge @renderCommon "--screenshot=$shots\app-step11-infer.png" "$base/shot-app-step11.html?state=infer" | Out-Null
& $edge @renderCommon "--screenshot=$shots\app-step11-cite.png" "$base/shot-app-step11.html?state=cite" | Out-Null

$testCommon = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=12000'
)

& $edge @testCommon "--screenshot=$shots\app-step11-test.png" "$base/test-app-step11.html" | Out-Null

Add-Type -AssemblyName System.Drawing
foreach ($n in 'app-step11-menu.png', 'app-step11-source.png', 'app-step11-infer.png', 'app-step11-cite.png', 'app-step11-test.png') {
  $i = [System.Drawing.Image]::FromFile("$shots\$n")
  "$n $($i.Width)x$($i.Height)"
  $i.Dispose()
}

function Count-Color($path, $r, $g, $b, $x0, $y0, $x1, $y1) {
  $bmp = [System.Drawing.Bitmap]::FromFile($path)
  $count = 0
  for ($y = $y0; $y -lt $y1; $y += 1) {
    for ($x = $x0; $x -lt $x1; $x += 1) {
      $c = $bmp.GetPixel($x, $y)
      if ($c.R -eq $r -and $c.G -eq $g -and $c.B -eq $b) { $count += 1 }
    }
  }
  $bmp.Dispose()
  return $count
}

"菜单底色 #232325 像素数：$(Count-Color "$shots\app-step11-menu.png" 35 35 37 0 0 1696 890)"
"来源弹窗底色 #1B1B1C 像素数：$(Count-Color "$shots\app-step11-source.png" 27 27 28 400 100 1300 800)"
"推理链弹窗底色 #1B1B1C 像素数：$(Count-Color "$shots\app-step11-infer.png" 27 27 28 400 100 1300 800)"
"chip 底色 #3A3B3F 像素数（底部输入区）：$(Count-Color "$shots\app-step11-cite.png" 58 59 63 290 700 1400 890)"

# 回归：第 6、8、9、10 步测试页在改动后的页面上重跑
& $edge @testCommon "--screenshot=$shots\app-step11-regress-step6.png" "$base/test-app-step6.html" | Out-Null
& $edge @testCommon "--screenshot=$shots\app-step11-regress-step8.png" "$base/test-app-step8.html" | Out-Null
& $edge @testCommon "--screenshot=$shots\app-step11-regress-step9.png" "$base/test-app-step9.html" | Out-Null
& $edge @testCommon "--screenshot=$shots\app-step11-regress-step10.png" "$base/test-app-step10.html" | Out-Null

foreach ($n in 'app-step11-regress-step6.png', 'app-step11-regress-step8.png', 'app-step11-regress-step9.png', 'app-step11-regress-step10.png') {
  $i = [System.Drawing.Image]::FromFile("$shots\$n")
  "$n $($i.Width)x$($i.Height)"
  $i.Dispose()
}
