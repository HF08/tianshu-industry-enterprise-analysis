Add-Type -AssemblyName System.Drawing

$refPath = $args[0]
$minePath = $args[1]
$outPath = $args[2]

$refImg = [System.Drawing.Image]::FromFile($refPath)
$refBmp = New-Object System.Drawing.Bitmap($refImg)
$mineImg = [System.Drawing.Image]::FromFile($minePath)
$mineBmp = New-Object System.Drawing.Bitmap($mineImg)

$w = $mineBmp.Width; $h = $mineBmp.Height

$small = New-Object System.Drawing.Bitmap($w, $h)
$g = [System.Drawing.Graphics]::FromImage($small)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g.DrawImage($refBmp, (New-Object System.Drawing.Rectangle(0, 0, $w, $h)))
$g.Dispose()

$rect = New-Object System.Drawing.Rectangle(0, 0, $w, $h)
$dr = $small.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$rb = New-Object 'byte[]' ($dr.Stride * $h)
[System.Runtime.InteropServices.Marshal]::Copy($dr.Scan0, $rb, 0, $rb.Length)
$rstride = $dr.Stride
$small.UnlockBits($dr)

$dm = $mineBmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$mb = New-Object 'byte[]' ($dm.Stride * $h)
[System.Runtime.InteropServices.Marshal]::Copy($dm.Scan0, $mb, 0, $mb.Length)
$mstride = $dm.Stride
$mineBmp.UnlockBits($dm)

$diff = New-Object System.Drawing.Bitmap($w, $h)
$dd = $diff.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::WriteOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$db = New-Object 'byte[]' ($dd.Stride * $h)
$dstride = $dd.Stride

$sum = 0.0; $close = 0; $total = 0
for ($y = 0; $y -lt $h; $y++) {
  for ($x = 0; $x -lt $w; $x++) {
    $ir = $y * $rstride + $x * 4
    $im = $y * $mstride + $x * 4
    $id = $y * $dstride + $x * 4
    $dr2 = [math]::Abs([int]$rb[$ir + 2] - [int]$mb[$im + 2])
    $dg = [math]::Abs([int]$rb[$ir + 1] - [int]$mb[$im + 1])
    $dbl = [math]::Abs([int]$rb[$ir] - [int]$mb[$im])
    $d = ($dr2 + $dg + $dbl) / 3.0
    $sum += $d
    if ($d -lt 24) { $close++ }
    $total++
    $v = [int][math]::Min(255, $d * 4)
    $db[$id] = $v; $db[$id + 1] = $v; $db[$id + 2] = $v; $db[$id + 3] = 255
  }
}
$diff.UnlockBits($dd)
$diff.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
$diff.Dispose(); $refBmp.Dispose(); $mineBmp.Dispose(); $refImg.Dispose(); $mineImg.Dispose()

"mean abs diff = {0:N2} / 255" -f ($sum / $total)
"pixels within 24 = {0:N2}%" -f (100.0 * $close / $total)
