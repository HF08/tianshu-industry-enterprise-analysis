$edge = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
$root = 'D:\workSpaceForDSH\工行黑客松-命题二'
$shots = "$root\_shots"
$preview = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/app/index.html'
$base = 'file:///D:/workSpaceForDSH/%E5%B7%A5%E8%A1%8C%E9%BB%91%E5%AE%A2%E6%9D%BE-%E5%91%BD%E9%A2%98%E4%BA%8C/_shots'
$profile = "$shots\edge-profile-step6"

$common = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=3000'
)

& $edge @common "--screenshot=$shots\app-step6-collapsed.png" $preview | Out-Null
& $edge @common "--screenshot=$shots\app-step6-expanded.png" "$base/shot-app-step6-expanded.html" | Out-Null
& $edge @common "--screenshot=$shots\app-step6-noactive.png" "$base/shot-app-step6-noactive.html" | Out-Null

$testCommon = @(
  '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', "--user-data-dir=$profile",
  '--force-device-scale-factor=1', '--window-size=1696,890', '--virtual-time-budget=8000'
)
& $edge @testCommon "--screenshot=$shots\app-step6-test.png" "$base/test-app-step6.html" | Out-Null

Add-Type -AssemblyName System.Drawing
foreach ($n in 'app-step6-collapsed.png', 'app-step6-expanded.png', 'app-step6-noactive.png', 'app-step6-test.png') {
  $i = [System.Drawing.Image]::FromFile("$shots\$n")
  "$n $($i.Width)x$($i.Height)"
  $i.Dispose()
}
